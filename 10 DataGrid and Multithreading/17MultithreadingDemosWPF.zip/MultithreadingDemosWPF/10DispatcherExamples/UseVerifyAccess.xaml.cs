using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;

namespace DispatcherExamples
{
    /// <summary>
    /// Interaction logic for UseVerifyAccess.xaml
    /// </summary>

    public partial class UseVerifyAccess : System.Windows.Window
    {

        public UseVerifyAccess()
        {
            InitializeComponent();

            fromUiButton.Click += new RoutedEventHandler(fromUiButton_Click);
            fromWrongButton.Click += new RoutedEventHandler(fromWrongButton_Click);
        }

        void fromWrongButton_Click(object sender, RoutedEventArgs e)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                TryCall();
            });
        }

        void fromUiButton_Click(object sender, RoutedEventArgs e)
        {
            TryCall();
        }

        private void TryCall()
        {
            string resultText;
            try
            {
                VerifyAccess();
                resultText = "Success";
            }
            catch (Exception x)
            {
                resultText = x.ToString();
            }
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, (ThreadStart)delegate
            {
                result.Text = resultText;
            });
        }
    }
}