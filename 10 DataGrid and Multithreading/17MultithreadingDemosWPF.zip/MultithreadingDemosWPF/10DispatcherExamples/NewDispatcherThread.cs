using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows;

namespace DispatcherExamples
{
    class NewDispatcherThread
    {
        // Starting a dispatcher on a new UI thread

        void StartDispatcher()
        {
            Thread thread = new Thread(MyDispatcherThreadProc);
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
        }

        void MyDispatcherThreadProc()
        {

            Window1 w = new Window1();
            w.Show();

            // Won't return until dispatcher shuts down
            System.Windows.Threading.Dispatcher.Run();
        }
    }

    public class Window1 : Window { }
}
