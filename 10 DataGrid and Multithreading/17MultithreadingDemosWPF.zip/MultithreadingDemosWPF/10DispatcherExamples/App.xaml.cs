using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace DispatcherExamples
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            MyWindow w2 = new MyWindow();
            w2.Show();

            PassParams w3 = new PassParams();
            w3.Show();
        }
    }
}