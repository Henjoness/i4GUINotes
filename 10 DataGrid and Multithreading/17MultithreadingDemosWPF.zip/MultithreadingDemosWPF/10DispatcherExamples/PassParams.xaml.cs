using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Threading;

namespace DispatcherExamples
{
    /// <summary>
    /// Interaction logic for MyWindow.xaml
    /// </summary>

    public partial class PassParams : System.Windows.Window
    {

        public PassParams()
        {
            InitializeComponent();

            useBeginInvokeButton.Click += new RoutedEventHandler(useBeginInvokeButton_Click);
        }

        void useBeginInvokeButton_Click(object sender, RoutedEventArgs e)
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                RunsOnWorkerThread();
            });
        }

        delegate void UsesColor(Color c);

        void SetBackgroundColor(Color c)
        {
            this.Background = new SolidColorBrush(c);
        }

        void RunsOnWorkerThread()
        {
            UsesColor methodForUiThread = SetBackgroundColor;
            Dispatcher.BeginInvoke(DispatcherPriority.Normal, methodForUiThread,
                                        Colors.Blue);
        }
    }
}