﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Http;
using System.Threading;

namespace AwaitAsync
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void btnGetHtml_Click(object sender, RoutedEventArgs e)
        {
            tbxLength.Text = "Fetching...";
            string url = tbxUrl.Text;
            HttpClient client = new HttpClient();
            string text = await client.GetStringAsync(url);
            tbxLength.Text = text.Length.ToString();
        }

        private async void btnGetHtml_Click_v2(object sender, RoutedEventArgs e)
        {
            tbxLength.Text = "Fetching...";
            string url = tbxUrl.Text;
            HttpClient client = new HttpClient();
            Task<string> task = client.GetStringAsync(url);
            string text = await task;
            //string text = task.Result;
            tbxLength.Text = text.Length.ToString();
        }

        private async void btnSyncCall_Click(object sender, RoutedEventArgs e)
        {
            tblSyncMessage.Text = "Starting slow work...";
            await Task.Run(() => DoSlowWork());
            //DoSlowWork();
            tblSyncMessage.Text = "Done doing slow work!";
        }

        private void DoSlowWork()
        {
            Thread.Sleep(4000);
        }

        async void btnDelayDemo_Click(object sender, RoutedEventArgs e)
        {
            tblbDelayDemo.Text = "Starts to wait...";
            await FooAsync().ConfigureAwait(true);  // Can't use false here!
            tblbDelayDemo.Text = "Done waiting!";
        }

        async Task FooAsync()
        { 
            await Task.Delay(4000).ConfigureAwait(false); 
        }

    }
}
