using System.Windows;
using System.ComponentModel;
using System.Threading;

namespace BackgroundWorkerExample
{

    partial class MyWindow : Window
    {

        BackgroundWorker bw;

        public MyWindow()
        {
            bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            bw.ProgressChanged += bw_ProgressChanged;
            bw.RunWorkerCompleted += bw_RunWorkerCompleted;
            bw.WorkerReportsProgress = true;
            bw.RunWorkerAsync();
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {

            // Running on a worker thread
            for (int i = 0; i < 10; ++i)
            {
                int percent = i * 10;
                bw.ReportProgress(percent);
                Thread.Sleep(1000);
               if (e.Cancel)
                  return;
            }

            // The BackgroundWorker will raise the RunWorkerCompleted
            // event when this method returns.
        }

        void bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            // Running on a UI thread
            this.Title = "Working: " + e.ProgressPercentage + "% done";
        }

        void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // Running on a UI thread
            this.Title = "Finished";
        }

    }
}