﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace DispatcherTimerDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer dt;
        Random rnd = new Random();

        public MainWindow()
        {
            InitializeComponent();
            dt = new DispatcherTimer();
            dt.Tick += dt_Tick;
            dt.Interval = TimeSpan.FromSeconds(2);
            dt.Start();
        }

        void dt_Tick(object sender, EventArgs e)
        {
            byte[] vals = new byte[3];
            rnd.NextBytes(vals);
            Color c = Color.FromRgb(vals[0], vals[1], vals[2]);

            // OK to touch UI elements, as the DispatchTimer
            // calls us back on the UI thread
            this.Background = new SolidColorBrush(c);
        }
    }
}
