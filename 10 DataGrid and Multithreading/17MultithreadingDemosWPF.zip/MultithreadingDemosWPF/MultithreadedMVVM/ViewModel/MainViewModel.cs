using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using System.Windows.Input;
using System.Threading;
using System.Collections.ObjectModel;
using System.Collections.Concurrent;
using System.Windows;
using System;

namespace MultithreadedMVVM.ViewModel
{
    /// <summary>
    /// This class contains properties that the main View can data bind to.
    /// <para>
    /// Use the <strong>mvvminpc</strong> snippet to add bindable properties to this ViewModel.
    /// </para>
    /// <para>
    /// You can also use Blend to data bind with the tool's support.
    /// </para>
    /// <para>
    /// See http://www.galasoft.ch/mvvm
    /// </para>
    /// </summary>
    public class MainViewModel : ViewModelBase
    {
        /// <summary>
        /// Initializes a new instance of the MainViewModel class.
        /// </summary>
        public MainViewModel()
        {
            if (IsInDesignMode)
            {
                // Code runs in Blend --> create design time data.
                Message = "Testing ... 1-2-3";
            }
            else
            {
                // Code runs "for real"
                Message = "Thread Not Started";
            } 
        }

        string message;

        public string Message
        {
            get { return message; }
            set 
            {
                if (value != message)
                {
                    message = value;
                    RaisePropertyChanged("Message");
                }
            }
        }
        
        private ICommand doWorkCommand = null;

        public ICommand DoWorkCommand
        {
            get 
            {
                if (doWorkCommand == null)
                    doWorkCommand = new RelayCommand(DoWorkExecute);
                return doWorkCommand; 
            }
        }

        private void DoWorkExecute()
        {
            Thread calcThread = new Thread(RunsOnWorkerThread);
            calcThread.Start();
            Message = "Thread Function started.";
        }

        private void RunsOnWorkerThread()
        {
            DoSomethingSlow();
            //Dispatcher.BeginInvoke is not needed - The data binding mechanics does the magic trick.
            Message = "Finished";
        }

        private void DoSomethingSlow()
        {
            Thread.Sleep(1000);
        }

        // --------------------

        private ICommand doOtherWorkCommand = null;

        public ICommand DoOtherWorkCommand
        {
            get
            {
                if (doOtherWorkCommand == null)
                    doOtherWorkCommand = new RelayCommand(DoListWorkExecute);
                return doOtherWorkCommand;
            }
        }

        private void DoListWorkExecute()
        {
            Thread listThread = new Thread(AddToListThread);
            //Thread listThread = new Thread(AddToListOnUIThread);
            listThread.Start();
        }

        ObservableCollection<string> list = new ObservableCollection<string>();
        //ConcurrentBag<string> list = new ConcurrentBag<string>();

        //public ConcurrentBag<string> List
        public ObservableCollection<string> List
        {
            get { return list; }
        }

        void AddToListThread()
        {
            for (int i = 0; i < 100; i++)
            {
                list.Add("Item " + i);
            }
        }

        void AddToListOnUIThread()
        {
            for (int i = 0; i < 100; i++)
            {
                Application.Current.Dispatcher.Invoke(new Action(() =>
                { list.Add("Item " + i); }));
            }
        }
    }
}