﻿define(function () {
    return function print(msg) {
        console.log(msg);
        var ptag = document.getElementsByTagName('p')[0];
        ptag.innerText = msg;
    };
});
