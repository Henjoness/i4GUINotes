﻿var names1 = ["Sunday", "Monday", "Tuesday", "Wednesday",
             "Thursday", "Friday", "Saturday"];
function dayName1(number) {
    return names1[number];
}

console.log(dayName1(1));

var dayName2 = function () {
    var names2 = ["Sunday", "Monday", "Tuesday", "Wednesday",
                 "Thursday", "Friday", "Saturday"];
    return function (number) {
        return names2[number];
    };
}();

console.log(dayName2(3));