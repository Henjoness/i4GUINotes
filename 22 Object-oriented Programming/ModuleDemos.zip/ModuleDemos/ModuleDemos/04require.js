﻿// Simple synchronous file get without error handling!
function getFile(url) {
    var req = new XMLHttpRequest();
    req.open("GET", url + ".js", false);
    req.send(null);
    return req.responseText;
}

function require(name) {
    if (name in require.cache)
        return require.cache[name];

    var code = new Function("exports, module", getFile(name));
    var exports = {}, module = { exports: exports };
    code(exports, module);

    require.cache[name] = module.exports;
    return module.exports;
}
require.cache = Object.create(null);

var weekday = require("weekDay");
alert(weekday.name(3));