﻿// Simple synchronous file get without error handling!
function getFile(url) {
    var req = new XMLHttpRequest();
    req.open("GET", url + ".js", false);
    req.send(null);
    return req.responseText;
}

function require(name) {
    var code = new Function("exports", getFile(name));
    var exports = {};
    code(exports);
    return exports;
}

var weekday = require("weekDay");
console.log(weekday.name(3));