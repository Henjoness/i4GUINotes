﻿class Polygon {
    constructor(height, width) {
        this.height = height;
        this.width = width;
    }
}

var obj = {
    // Setting the prototype
    __proto__: theProtoObj,
    // Shorthand for ‘handler: handler’
    handler,
    // Methods
    toString() {
        // Super calls
        return "d " + super.toString();
    },
    // Computed (dynamic) property names
    ['prop_' +(() => 42) ()]: 42
};
