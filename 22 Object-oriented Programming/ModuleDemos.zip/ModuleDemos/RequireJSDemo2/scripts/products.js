﻿define(function () {
    return {
        reserveProduct: function () {
            console.log("Function : reserveProduct");

            return true;
        }
    }
});