﻿require(["purchase"], function (purchase) {
    purchase.purchaseProduct();
});