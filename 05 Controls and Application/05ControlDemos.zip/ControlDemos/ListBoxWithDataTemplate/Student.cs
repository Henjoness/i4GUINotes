﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListBoxWithDataTemplate
{
    public class Student
    {
        public string GivenName { get; set; }
        public string FamilyName { get; set; }
        public string Id { get; set; }
        public int Grade { get; set; }
    }
}
