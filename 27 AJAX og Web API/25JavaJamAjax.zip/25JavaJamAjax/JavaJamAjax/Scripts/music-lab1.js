﻿//Music-lab1.js

$('#melaniethumb').click(function(event){
    event.preventDefault();
    $("#malanieModal").modal('show');
});

$('#gregthumb').click(function(event){
    event.preventDefault();
    $('#gregModal').modal('show');
});
