﻿using MyModels;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebAppScaffold.DataAccess
{
    public class MovieDBContext : DbContext
    {
        public DbSet<Movie> Movies { get; set; }

        public MovieDBContext()
            : base("DefaultConnection")
        {
        }
    }
}
