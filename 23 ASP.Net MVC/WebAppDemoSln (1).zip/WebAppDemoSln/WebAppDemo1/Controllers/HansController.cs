﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAppDemo1.Controllers
{
    public class HansController : Controller
    {
        // GET: Hans
        public ActionResult Index()
        {
            return View();
        }
    }
}