﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebAppDemo1.Models;

namespace WebAppDemo1.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            ViewBag.Hugo = "Hej Fantstiske I4";
            var st = new Student() { Name = "Amanda", Grade = 12 };
            return View(st);
        }

        public ActionResult Foo(int id = 12)
        {
            ViewBag.Hugo = "Hej Fantstiske I4";
            var st = new Student() { Name = "Amanda", Grade = id };
            return View(st);
        }
    }
}