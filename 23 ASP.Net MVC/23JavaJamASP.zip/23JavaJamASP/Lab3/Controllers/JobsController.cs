﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Lab3.Controllers
{
    public class JobsController : Controller
    {
        // GET: Jobs
        public ActionResult Index()
        {
            return View();
        }

        
        // POST: Jobs/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // Add the job application to a file
                var name = collection["aName"];
                var email = collection["aEmail"];
                var expirience = Request["aExpirience"];
                var userData = "Name: " + name + ", E-mail: " + email +
                    ", Expirience:" + expirience + Environment.NewLine;

                var dataFile = Server.MapPath("~/App_Data/data.txt");
                System.IO.File.AppendAllText(@dataFile, userData);

                return View("Confirmation");
            }
            catch
            {
                return View("Error");
            }
        }

    }
}
