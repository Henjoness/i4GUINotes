Delopgave 1
-----------------
Den enkelste m�de at l�se opgaven p� er at indlejre javascriptkoden i footeren, og s� benytte document.write. Men intrusive JavaScript 
kan godt v�re sv�r at vedligeholde, s� derfor  er denne l�sning udkommenteret og i stedet benytter jeg document.getElementById('footer')
og s� tilf�jer jeg teksten til innerHTML propertyen.
Se l�sning nederst i husic.html.

Delopgave 2
-----------------
Den hurtige l�sning med intrusive JavaScript vil v�re at �ndre den f�rste p-tag til: <p onmouseover="alert('Conserts sell out quickly so act fast!');">
En bedre l�sning er:  var firstP = document.getElementById("content").firstElementChild;
Se l�sning nederst i husic.html.

Delopgave 3
-----------------
Bruger getElementById til at koble en click-eventhandler p� anchor-elementerne. Ved Melanie �bner jeg blot et nyt vindue og 
med event.preventDefault() undertrykker jeg browserens normale reaktion ved klik p� et anchor-element, s� den bliver p� music-siden.
Ved Greg har jeg tilf�jet et timer-event, s� vinduet automatisk lukkes efter 2 sekunder.

Delopgave 4
-----------------
�ndre alle menuvalg s�ledes at li-elementet f�r class=menu, f.eks.: <li class="menu"><a href="index.html">Home</a></li>
Og i JavaJam.cs (som tilf�jes alle html-filerne) starter jeg med at finde alle menu-valg: document.getElementsByClassName("menu");
De funde menuvalg genneml�bes i en for-l�kke, og hver at dem tilf�jes en eventhandler for mouseover og mouseout. 
I mouseover eventhandleren �ndres elementets className til "menuEnhanced", som er defineret i javajam.css til at give fremh�vet skrift.
I mouseout eventhandleren �ndres elementets className tilbage til menu.