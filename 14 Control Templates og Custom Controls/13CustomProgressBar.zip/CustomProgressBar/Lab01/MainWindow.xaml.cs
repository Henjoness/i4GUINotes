﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace Lab01
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            pgbSeconds.Minimum = 0;
            pgbSeconds.Maximum = 59;
            timer.Interval = TimeSpan.FromSeconds(1.0);
            timer.Tick += timer_Tick;
            timer.IsEnabled = true;
        }

        void timer_Tick(object sender, EventArgs e)
        {
            pgbSeconds.Value = DateTime.Now.Second;
        }
    }
}
