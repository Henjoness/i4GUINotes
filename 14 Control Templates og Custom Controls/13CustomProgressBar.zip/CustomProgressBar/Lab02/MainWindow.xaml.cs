﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Lab02
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();
            pgbSeconds.Minimum = 0;
            pgbSeconds.Maximum = 59;
            timer.Interval = TimeSpan.FromSeconds(1.0);
            timer.Tick += timer_Tick;
            timer.IsEnabled = true;
        }

        void timer_Tick(object sender, EventArgs e)
        {
            var sec = DateTime.Now.Second;
            if (sec < 45)
                pgbSeconds.Value = sec + 15;
            else
                pgbSeconds.Value = -45 + sec;
            lblSeconds.Content = sec.ToString();
        }
    }
}
