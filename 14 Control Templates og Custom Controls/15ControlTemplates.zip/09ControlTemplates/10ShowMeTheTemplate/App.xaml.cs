﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using System.Reflection;
using System.Windows.Controls;
using System.IO;
using System.Windows.Forms.Integration;
using System.Xml;
using System.Windows.Markup;
using System.Windows.Navigation;
using System.Diagnostics;

namespace _10ShowMeTheTemplate
{
   /// <summary>
   /// Interaction logic for App.xaml
   /// </summary>
   public partial class App : Application
   {
      public static IEnumerable<Type> GetTemplatePartTypes(Assembly assem)
      {
         foreach (Type type in assem.GetTypes())
         {
            if (!type.IsPublic) { continue; }
            if (type.GetCustomAttributes(typeof(TemplatePartAttribute), false).Length == 0) { continue; }
            yield return type;
         }
      }

      protected override void OnStartup(StartupEventArgs e)
      {
         base.OnStartup(e);

         List<Type> templatePartTypes = new List<Type>(GetTemplatePartTypes(Assembly.LoadWithPartialName("PresentationFramework")));
         templatePartTypes.Sort(delegate(Type lhs, Type rhs) { return lhs.Name.CompareTo(rhs.Name); });

         foreach (Type type in templatePartTypes)
         {
            //Debug.WriteLine(string.Format("{0}: ", type.Name));
            foreach (TemplatePartAttribute attrib in type.GetCustomAttributes(typeof(TemplatePartAttribute), false))
            {
               Debug.WriteLine(string.Format("{0}, {1}, {2}", type.Name, attrib.Name, attrib.Type.Name));
            }
         }
      }
   }
}
