﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace _05SimpleControlTemplate
{
   public class PlayerMove : INotifyPropertyChanged
   {
      string playerName;
      public string PlayerName
      {
         get { return playerName; }
         set
         {
            if (string.Compare(playerName, value) == 0) { return; }
            playerName = value;
            Notify("PlayerName");
         }
      }

      int moveNumber;
      public int MoveNumber
      {
         get { return moveNumber; }
         set
         {
            if (moveNumber == value) { return; }
            moveNumber = value;
            Notify("MoveNumber");
         }
      }

      bool isPartOfWin = false;
      public bool IsPartOfWin
      {
         get { return isPartOfWin; }
         set
         {
            if (isPartOfWin == value) { return; }
            isPartOfWin = value;
            Notify("IsPartOfWin");
         }
      }

      public PlayerMove(string playerName, int moveNumber)
      {
         this.playerName = playerName;
         this.moveNumber = moveNumber;
      }

      // INotifyPropertyChanged Members
      public event PropertyChangedEventHandler PropertyChanged;
      void Notify(string propName)
      {
         if (PropertyChanged != null)
         {
            PropertyChanged(this, new PropertyChangedEventArgs(propName));
         }
      }
   }
}
