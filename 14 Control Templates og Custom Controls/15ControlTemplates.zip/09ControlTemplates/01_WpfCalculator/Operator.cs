﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WpfCalculator
{
    public enum Operator
    {
        None,
        Plus,
        Minus,
        Times,
        Divide,
        Equals
    }
}
