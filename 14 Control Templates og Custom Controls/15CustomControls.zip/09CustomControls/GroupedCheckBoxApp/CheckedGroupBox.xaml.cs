﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GroupedCheckBoxApp
{
	/// <summary>
	/// Interaction logic for CheckedGroupBox.xaml
	/// </summary>
	public partial class CheckedGroupBox : UserControl
	{
		public CheckedGroupBox()
		{
			InitializeComponent();
		}

		// --------------------------------------------
		// Properties

		public static DependencyProperty CheckBoxContentProperty;
		public static DependencyProperty GroupBoxContentProperty;

		static CheckedGroupBox()
		{
			CheckBoxContentProperty = DependencyProperty.Register("CheckBoxContent", typeof(object), typeof(CheckedGroupBox));

			PropertyMetadata groupBoxMetaData = new PropertyMetadata(new PropertyChangedCallback(OnContentChanged));
			GroupBoxContentProperty = DependencyProperty.Register("GroupBoxContent", typeof(object), typeof(CheckedGroupBox),groupBoxMetaData);
		}

		public bool? IsChecked
		{
			get { return checkBox1.IsChecked; }
			set { checkBox1.IsChecked = value; }
		}

		public object CheckBoxContent
		{
			get { return GetValue(CheckBoxContentProperty); }
			set { SetValue(CheckBoxContentProperty, value); }
		}

		public object GroupBoxContent
		{
			get { return GetValue(GroupBoxContentProperty); }
			set { SetValue(GroupBoxContentProperty, value); }
		}

		private static void OnContentChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
		{
			CheckedGroupBox cgb = dependencyObject as CheckedGroupBox;
			cgb.CheckBox_CheckChanged(cgb.checkBox1, new RoutedEventArgs());
		}

		private void CheckBox_CheckChanged(object sender, RoutedEventArgs e)
		{
			CheckBox cb = sender as CheckBox;

			if (GroupBoxContent is UIElement)
			{
				UIElement element = (UIElement)GroupBoxContent;
				element.IsEnabled = (bool)cb.IsChecked;
			}
		}
	}
}
