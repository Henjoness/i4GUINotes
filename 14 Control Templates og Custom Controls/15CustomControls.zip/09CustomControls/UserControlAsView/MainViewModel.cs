﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BMICalculator;

namespace UserControlAsView
{
    public class MainViewModel
    {
        public BMIViewModel BmiViewModel
        {
            get { return new BMIViewModel(new BMIModel()); }
        }
    }
}
