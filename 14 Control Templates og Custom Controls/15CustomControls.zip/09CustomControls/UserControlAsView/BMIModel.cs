﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BMICalculator
{
    public class BMIModel
    {
        public double Weight { set; get; }

        public double Height { set; get; }

        public double CalculateBMI()
        {
            return Weight / (Height * Height);
        }
    }
}
