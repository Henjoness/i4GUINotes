﻿using MvvmFoundation.Wpf;
using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;


namespace BMICalculator
{
    public class BMIViewModel : INotifyPropertyChanged
    {
        BMIModel bmiModel;

        public BMIViewModel(BMIModel theModel)
        {
            bmiModel = theModel;

            if ((bool)(DesignerProperties.IsInDesignModeProperty.GetMetadata(typeof(DependencyObject)).DefaultValue))
            {
                // In Design mode so add some dummy data for the Designer
                bmiModel.Height = 1.87;
                bmiModel.Weight = 83;
                bmi = 23.3;
            }
        }

        #region Properties

        public double Height
        {
            get { return bmiModel.Height; }
            set 
            {
                if (value != bmiModel.Height)
                {
                    bmiModel.Height = value;
                    NotifyPropertyChanged();
                }
            }
        }

        public double Weight
        {
            get { return bmiModel.Weight; }
            set
            {
                if (value != bmiModel.Weight)
                {
                    bmiModel.Weight = value;
                    NotifyPropertyChanged();
                }
            }
        }

        double bmi;
        public double BMI
        {
            get { return bmi; }
        }

        #endregion

        #region Commands

        ICommand _calcBMICommand;
        public ICommand CalcBMICommand
        {
            get { return _calcBMICommand ?? (_calcBMICommand = new RelayCommand(CalcBMI, CalcBMICanExecute)); }
        }

        private void CalcBMI()
        {
            bmi = bmiModel.CalculateBMI();
            NotifyPropertyChanged("BMI");
        }

        private bool CalcBMICanExecute()
        {
            if (Weight != 0.0 && Height != 0.0)
                return true;
            else
                return false;
        }

        #endregion

        #region INotifyPropertyChanged implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
        #endregion
    }
}
