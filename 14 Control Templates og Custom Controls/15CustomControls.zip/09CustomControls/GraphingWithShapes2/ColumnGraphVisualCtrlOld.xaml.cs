﻿using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;
using System.Windows;
using System.Windows.Controls;
//using System.Windows.Data;
//using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
//using System.Windows.Media.Imaging;
//using System.Windows.Navigation;
//using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Globalization;

namespace GraphingWithShapes
{
    /// <summary>
    /// Interaction logic for ColumnGraphVisualCtrlOld.xaml
    /// </summary>
    public partial class ColumnGraphVisualCtrlOld : FrameworkElement
    {
        private ObservableCollection<NameValuePair> dataPoints = null;
        private List<Color> columnColors = new List<Color>() { Colors.Blue, Colors.Red, Colors.Green };
        private VisualCollection visuals;

        public ColumnGraphVisualCtrlOld()
        {
            visuals = new VisualCollection(this);
            InitializeComponent();
        }

        public void SetData(ObservableCollection<NameValuePair> data)
        {
            dataPoints = data;
            dataPoints.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(_dataPoints_CollectionChanged);
            Update();
            //InvalidateVisual();
        }

        void _dataPoints_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            //InvalidateVisual();
            Update();
        }

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            if (e.ClickCount == 2)
            {
                Point pt = e.GetPosition(this);

                HitTestResult result = VisualTreeHelper.HitTest(this, pt);
                if (result != null)
                {
                    foreach (NameValuePair nvp in dataPoints)
                    {
                        if (nvp.Tag == result.VisualHit)
                        {
                            MessageBox.Show("Name: " + nvp.Name + ", Value: " + nvp.Value.ToString());
                            break;
                        }
                    }
                }
            }
        }

        protected void Update()
        {
            visuals.Clear();

            if (dataPoints != null)
            {
                double spaceToUseY = ActualHeight * 0.7;
                double spaceToUseX = ActualWidth * 0.8;
                double barWidth = spaceToUseX / dataPoints.Count;
                double largestValue = GetLargestValue();
                double unitHeight = spaceToUseY / largestValue;

                double bottom = ActualHeight * 0.8;
                double left = ActualWidth * 0.1;

                Brush fillBrush;
                Pen outlinePen = new Pen(Brushes.Black, 1);
                int nIndex = 0;
                Rect rect;
                double height;
                DrawingVisual visual;
                foreach (NameValuePair nvp in dataPoints)
                {
                    visual = new DrawingVisual();
                    using (DrawingContext drawingContext = visual.RenderOpen())
                    {
                        fillBrush = new SolidColorBrush(columnColors[nIndex % columnColors.Count]);

                        height = (nvp.Value * unitHeight);
                        rect = new Rect(left, bottom - height, barWidth, height);
                        drawingContext.DrawRectangle(fillBrush, outlinePen, rect);

                        FormattedText ft = new FormattedText(nvp.Name,
                            CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface("Verdana"), 12, fillBrush);
                        ft.TextAlignment = TextAlignment.Center;
                        drawingContext.DrawText(ft, new Point((left + rect.Width / 2), bottom + 10));
                        //drawingContext.PushTransform(new RotateTransform(90));
                        //drawingContext.DrawText(ft,new Point((bottom+10),-(left + rect.Width /2)));
                        //drawingContext.Pop();
                    }
                    visuals.Add(visual);
                    nvp.Tag = visual;

                    left += rect.Width;
                    nIndex++;
                }
            }
        }

        public double GetLargestValue()
        {
            double value = 0;
            foreach (NameValuePair nvp in dataPoints)
            {
                value = Math.Max(value, nvp.Value);
            }

            return value;
        }

        protected override int VisualChildrenCount
        {
            get { return visuals.Count; }
        }

        protected override Visual GetVisualChild(int index)
        {
            return visuals[index];
        }


        private void FrameworkElement_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            Update();
        }
    }
}
