﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace GraphingWithShapes
{
	/// <summary>
	/// Interaction logic for GraphHolder.xaml
	/// </summary>
	public partial class GraphHolder : UserControl
	{
		ObservableCollection<NameValuePair> dataPoints = new ObservableCollection<NameValuePair>();

		public GraphHolder()
		{
			InitializeComponent();
		}
		
		private void UserControl_Loaded(object sender, RoutedEventArgs e)
		{
			// Add some points so I don't have to keep retyping them
			dataPoints.Add(new NameValuePair("First", 10));
			dataPoints.Add(new NameValuePair("Second", 20));
			dataPoints.Add(new NameValuePair("Third", 5));
			dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));
            dataPoints.Add(new NameValuePair("First", 10));
            dataPoints.Add(new NameValuePair("Second", 20));
            dataPoints.Add(new NameValuePair("Third", 5));
            dataPoints.Add(new NameValuePair("Fourth", 15));
            dataPoints.Add(new NameValuePair("Fifth", 34));
            dataPoints.Add(new NameValuePair("Sixth", 3));
            dataPoints.Add(new NameValuePair("Seventh", 40));
            dataPoints.Add(new NameValuePair("Eigth", 12));
            dataPoints.Add(new NameValuePair("Ninth", 3));
            dataPoints.Add(new NameValuePair("Tenth", 17));

			// Bind the listbox to the collection
			Binding binding = new Binding();
			binding.Source = dataPoints;
			valuesList.SetBinding(ListBox.ItemsSourceProperty, binding);
			graphCtrl.SetData(dataPoints);
		}

		private void addValueBtn_Click(object sender, RoutedEventArgs e)
		{
			string name = addValueNameTextBox.Text.Trim();
			if (name.Length == 0)
			{
				MessageBox.Show("Please enter a name");
				return;
			}

			string valueAsString = addValueValueTextBox.Text.Trim();
			double valueAsDouble = 0;
			try
			{
				valueAsDouble = Convert.ToDouble(valueAsString);
			}
			catch (FormatException)
			{
				MessageBox.Show("Please enter a valid value");
				return;
			}

			NameValuePair nvp = new NameValuePair(name, valueAsDouble);
			dataPoints.Add(nvp);
			//valuesList.Items.Add(nvp);

			addValueNameTextBox.Text = "";
			addValueValueTextBox.Text = "";
		}

		private void valuesList_KeyDown(object sender, KeyEventArgs e)
		{
			if ((e.Key == Key.Delete) && (valuesList.SelectedIndex >= 0))
			{
				dataPoints.RemoveAt(valuesList.SelectedIndex);
			}
		}
	}
}
