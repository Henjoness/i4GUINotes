﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;

namespace GraphingWithShapes
{
	/// <summary>
	/// Interaction logic for ColumnGraphCtrl.xaml
	/// </summary>
	public partial class ColumnGraphCtrl : UserControl
	{
		private ObservableCollection<NameValuePair> dataPoints = null;
		private List<Color> columnColors = new List<Color>() { Colors.Blue, Colors.Red, Colors.Green };

		public ColumnGraphCtrl()
		{
			InitializeComponent();
		}

		public void SetData(ObservableCollection<NameValuePair> data)
		{
			dataPoints = data;
			dataPoints.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(dataPoints_CollectionChanged);
			Update();
		}

		void dataPoints_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
		{
			Update();
		}

		/// <summary>Called when data has changed - graph must be updated</summary>
		public void Update()
		{
			//if (_dataPoints == null)
			//    return;

			Dictionary<Rectangle,NameValuePair> usedRects = new Dictionary<Rectangle,NameValuePair>();

			Rectangle rect;
			//int nIndex = 0;
			foreach (NameValuePair nvp in dataPoints)
			{
				if (nvp.Tag == null)
				{
					// Make sure that there is one rectangle for each data-point
					rect = new Rectangle();
					rect.Stroke = Brushes.Black;
					rect.StrokeThickness = 1;
					rect.MouseDown += new MouseButtonEventHandler(rect_MouseDown);
					rect.Tag = nvp;
					usedRects[rect] = nvp;
					main.Children.Add(rect);
					nvp.Tag = rect;
				}
				else
				{
					usedRects[nvp.Tag as Rectangle] = nvp;
				}
				//nIndex++;
			}

			// Get rid of unused rects
			int i = 0;
			UIElement elem;
			while(i < main.Children.Count)
			{
				elem = main.Children[i];
				if ((elem is Rectangle) && !usedRects.ContainsKey((Rectangle)elem))
					main.Children.RemoveAt(i);
				else
					i++;
			}

			CalculatePositionsAndSizes();
		}

		private void rect_MouseDown(object sender, MouseButtonEventArgs e)
		{
			if (e.ClickCount == 2)
			{
				Rectangle rect = sender as Rectangle;
				NameValuePair nvp = rect.Tag as NameValuePair;// FindNVPForTag(rect);

				if (nvp != null)
					MessageBox.Show("Name: " + nvp.Name + ", Value: " + nvp.Value.ToString());
			}
		}

		protected NameValuePair FindNVPForTag(object o)
		{
			NameValuePair nvp = null;

			foreach (NameValuePair nvpStep in dataPoints)
			{
				if (nvpStep.Tag == o)
				{
					nvp = nvpStep;
					break;
				}
			}

			return nvp;
		}


		public void CalculatePositionsAndSizes()
		{
			if (dataPoints == null)
				return;

			double spaceToUseY = main.ActualHeight * 0.8;
			double spaceToUseX = main.ActualWidth * 0.8;

			double barWidth = spaceToUseX / dataPoints.Count;
			double largestValue = GetLargestValue();
			double unitHeight = spaceToUseY / largestValue;

			double bottom = main.ActualHeight * 0.1;
			double left = main.ActualWidth * 0.1;

			Rectangle rect;
			int nIndex = 0;
			foreach (NameValuePair nvp in dataPoints)
			{
				rect = nvp.Tag as Rectangle;
				if (rect != null)
				{
					rect.Width = barWidth;
					rect.Height = nvp.Value * unitHeight;
					rect.Fill = new SolidColorBrush(columnColors[nIndex++ % columnColors.Count]);
					Canvas.SetLeft(rect, left);
					Canvas.SetBottom(rect, bottom);
					left += rect.Width;
				}
			}
		}

		public double GetLargestValue()
		{
			double value = 0;
			foreach (NameValuePair nvp in dataPoints)
			{
				value = Math.Max(value, nvp.Value);
			}

			return value;
		}

		private void main_SizeChanged(object sender, SizeChangedEventArgs e)
		{
			CalculatePositionsAndSizes();
		}
	}
}
