﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace UCinMvvmApp
{
    public class MainViewModel : INotifyPropertyChanged
    {
        Agents agents;

        public MainViewModel(bool inDesignMode)
        {
            agents = new Agents();
            if (inDesignMode)
            {
                agents.Add(new Agent("001", "Nina", "Assassination", "UpperVolta"));
                agents.Add(new Agent("007", "James Bond", "Martinis", "North Korea"));
            }
        }

        public IReadOnlyList<Agent> AgentList { get { return agents; } }
        public object RightPanel 
        { 
            get { return new AgentViewModel(CurrentAgent); }
            set
            {

            }
        }

        Agent currentAgent = null;

        public Agent CurrentAgent
        {
            get { return currentAgent; }
            set
            {
                if (currentAgent != value)
                {
                    currentAgent = value;
                    NotifyPropertyChanged();
                    NotifyPropertyChanged("RightPanel");
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] string propertyName = null)
        {
            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
