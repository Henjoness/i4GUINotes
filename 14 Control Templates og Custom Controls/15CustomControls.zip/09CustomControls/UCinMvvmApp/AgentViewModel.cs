﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UCinMvvmApp
{
    public class AgentViewModel
    {
        Agent agent;

        public AgentViewModel(Agent agentArg)
        {
            agent = agentArg;
        }

        public Agent Agent { get { return agent; } }
    }
}
