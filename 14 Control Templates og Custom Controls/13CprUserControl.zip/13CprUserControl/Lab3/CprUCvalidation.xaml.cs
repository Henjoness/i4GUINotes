﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for CprUCvalidation.xaml
    /// </summary>
    public partial class CprUCvalidation : UserControl
    {
        public enum CprError { NoError, FormatError, DateError, Check11Error };

        public CprUCvalidation()
        {
            InitializeComponent();
        }

        public string LabelText
        {
            get { return lblCprNo.Content.ToString(); }
            set { lblCprNo.Content = value; }
        }

        public string CprNo
        {
            get { return txbCprNo.Text; }
            set { txbCprNo.Text = value; }
        }

        public bool IsValid(out CprError errorCode, out string errorMessage)
        {
            const int cprLength = 10;
            errorCode = CprError.NoError;
            errorMessage = "";

            // Check length
            if (CprNo.Length != cprLength)
            {
                errorCode = CprError.FormatError;
                errorMessage = "The CPR entered must contain exactly 10 digits!";
                return false;
            }

            // Check only digits
            if (!CprNo.All(c => c >= '0' && c <= '9'))
            {
                errorCode = CprError.FormatError;
                errorMessage = "The CPR entered must only contain digits!";
                return false;
            }

            // Check date
            errorCode = DateTest(CprNo);

            if (errorCode == CprError.DateError)
            {
                errorMessage = "The CPR entered is not a valid CPR number. The date isn't valid!";
                return false;
            }

            // Check 11-test (checksum) 
            errorCode = Check11Test(CprNo);

            if (errorCode == CprError.Check11Error)
            {
                errorMessage = "The CPR entered is not a valid CPR number. Checksum test failed!";
                return false;
            }

            return true;
        }

        private CprError DateTest(string cprTxt)
        {
            string dayStr = cprTxt.Substring(0, 2);
            string monthStr = cprTxt.Substring(2, 2);
            string yearStr = cprTxt.Substring(4, 2);
            CprError cprError = CprError.NoError;

            int day;
            int month;
            int year;

            try
            {
                day = int.Parse(dayStr);
                month = int.Parse(monthStr);
                year = int.Parse(yearStr);
                DateTime dt = new DateTime(year, month, day);
            }
            catch (Exception)
            {
                cprError = CprError.DateError;
            }
            return cprError;
        }

        private CprError Check11Test(string cprTxt)
        {
            /// <summary>
            /// The CPR check sum algorithm is calculated by mulitiplying each digit with a factor 
            /// and then add all results and divide the sum by 11.
            /// Factors: 4327654321
            /// CPR:     0609240121
            /// Sum:     0 + 18 + 0 + 72 + 12 + 20 + 0 + 1 + 4 + 1 = 121 / 11 = 11.0 -> CPR is OK
            /// </summary>
            ///
            CprError cprError = CprError.NoError;
            try
            {
                int sum = 0;
                for (int i = 0; i < 3; i++)
                    sum += int.Parse(cprTxt.Substring(i, 1)) * (4 - i);
                for (int i = 3; i < 10; i++)
                    sum += int.Parse(cprTxt.Substring(i, 1)) * (10 - i);
                if (sum % 11 != 0)
                    cprError = CprError.Check11Error;
            }
            catch (Exception)
            {
                cprError = CprError.FormatError;
            }

            return cprError;
        }
    }
}
