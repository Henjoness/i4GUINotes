﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // Data members
        CprUCvalidation.CprError errorCode; 
        string errorMessage;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show(ucCprNo.CprNo, "CprNo");
        }

        private void btnChangeLbl_Click(object sender, RoutedEventArgs e)
        {
            if (ucCprNo.LabelText != "Cpr no.:")
                ucCprNo.LabelText = "Cpr no.:";
            else
                ucCprNo.LabelText = "Cpr-nummer:";
        }

        private void btnValidate_Click(object sender, RoutedEventArgs e)
        {
            if (!ucCprNo.IsValid(out errorCode, out errorMessage))
                MessageBox.Show(errorMessage, "Cpr error");
            else
                MessageBox.Show("The CPR number is valid", "Validation result");
        }

        private void ucCprNo_LostFocus(object sender, RoutedEventArgs e)
        {
                if (!ucCprNo.IsValid(out errorCode, out errorMessage))
                tbkErrorMessage.Text = errorMessage;
            else
                tbkErrorMessage.Text = "";
        }
    }
}
