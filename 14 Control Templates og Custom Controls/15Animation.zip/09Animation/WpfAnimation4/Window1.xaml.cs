﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace WpfAnimation4
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      private Storyboard _enter;
      private Storyboard _leave;

      public Window1()
      {
         InitializeComponent();

         DoubleAnimation animation1 = new DoubleAnimation();
         animation1.To = 18.0;
         animation1.Duration = TimeSpan.FromMilliseconds(5000);
         Storyboard.SetTargetName(animation1, _button1.Name);
         Storyboard.SetTargetProperty(animation1, new PropertyPath(Button.FontSizeProperty));
         _enter = new Storyboard();
         _enter.Children.Add(animation1);

         DoubleAnimation animation2 = new DoubleAnimation();
         animation2.Duration = TimeSpan.FromMilliseconds(5000);
         Storyboard.SetTargetName(animation2, _button1.Name);
         Storyboard.SetTargetProperty(animation2, new PropertyPath(Button.FontSizeProperty));
         _leave = new Storyboard();
         _leave.Children.Add(animation2);

         _button1.MouseEnter += new MouseEventHandler(_button1_MouseEnter);
         _button1.MouseLeave += new MouseEventHandler(_button1_MouseLeave);
      }

      void _button1_MouseEnter(object sender, MouseEventArgs e)
      {
         _enter.Begin(this);
      }

      void _button1_MouseLeave(object sender, MouseEventArgs e)
      {
         _leave.Begin(this);
      }
   }
}
