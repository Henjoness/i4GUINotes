﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace ManualAnimation
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      private long _start;

      public Window1()
      {
         InitializeComponent();
         DispatcherTimer timer = new DispatcherTimer();
         timer.Interval = TimeSpan.FromMilliseconds(50);
         _start = Environment.TickCount;
         timer.Tick += new EventHandler(timer_Tick);
         timer.IsEnabled = true;
      }

      void timer_Tick(object sender, EventArgs e)
      {
         long elapsed = Environment.TickCount - _start;
         if (elapsed >= 5000)
         {
            _button1.FontSize = 18.0;
            ((DispatcherTimer)sender).IsEnabled = false;
            return;
         }
         _button1.FontSize = 9.0 + (9.0 / (5000.0 / elapsed));
      }
   }
}