﻿using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace WpfAnimation5
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      public Window1()
      {
         InitializeComponent();

         _button1.MouseEnter += new MouseEventHandler(Button1MouseEnter);
         _button1.MouseLeave += new MouseEventHandler(Button1MouseLeave);
         //_button1.
      }

      void Button1MouseEnter(object sender, MouseEventArgs e)
      {
         ((Storyboard)FindResource("_enter")).Begin(this);
      }

      void Button1MouseLeave(object sender, MouseEventArgs e)
      {
         ((Storyboard)FindResource("_leave")).Begin(this);
      }
   }
}
