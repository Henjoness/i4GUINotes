﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;

namespace WpfAnimation3
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      public Window1()
      {
         InitializeComponent();
         _button1.MouseEnter += new MouseEventHandler(_button1_MouseEnter);
         _button1.MouseLeave += new MouseEventHandler(_button1_MouseLeave);
      }

      void _button1_MouseEnter(object sender, MouseEventArgs e)
      {
         DoubleAnimation animation = new DoubleAnimation();
         animation.To = 18.0;
         animation.Duration = TimeSpan.FromMilliseconds(5000);
         _button1.BeginAnimation(Button.FontSizeProperty, animation);
      }

      void _button1_MouseLeave(object sender, MouseEventArgs e)
      {
         DoubleAnimation animation = new DoubleAnimation();
         animation.Duration = TimeSpan.FromMilliseconds(5000);
         _button1.BeginAnimation(Button.FontSizeProperty, animation);
      }
   }
}
