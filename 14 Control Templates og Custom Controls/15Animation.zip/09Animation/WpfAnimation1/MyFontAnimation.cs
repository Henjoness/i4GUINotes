﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Animation;

namespace WpfAnimation1
{
   public class MyFontAnimation : AnimationTimeline
   {
      private double _from = 9.0;
      private double _to = 18.0;

      public double From { get { return _from; } set { _from = value; } }
      public double To { get { return _to; } set { _to = value; } }

      public MyFontAnimation()
      {
      }

      public override Type TargetPropertyType
      {
         get { return typeof(double); }
      }

      public override object GetCurrentValue(object defaultOriginValue,
                                             object defaultDestinationValue, 
                                             AnimationClock animationClock)
      {
         TimeSpan? current = animationClock.CurrentTime;
         double increase = _to - _from;
         return _from + (increase / ((double)Duration.TimeSpan.Ticks / (double)current.Value.Ticks));
      }

      protected override System.Windows.Freezable CreateInstanceCore()
      {
         return new MyFontAnimation();
      }
   }
}
