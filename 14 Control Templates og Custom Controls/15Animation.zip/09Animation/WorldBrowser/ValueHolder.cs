﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;

namespace WorldBrowser 
{
	public class ValueHolder : Freezable, INotifyPropertyChanged
	{
		public ValueHolder()
		{
		}

		public static DependencyProperty DoubleValueProperty;

		static ValueHolder()
		{
			PropertyMetadata pm = new PropertyMetadata(800,null,null);
			DoubleValueProperty = DependencyProperty.Register("DoubleValue", typeof(double), typeof(ValueHolder),pm);
		}

		public double DoubleValue
		{
			get {return (double)GetValue(DoubleValueProperty);}
			set { SetValue(DoubleValueProperty, value); }
		}

		protected override Freezable CreateInstanceCore()
		{
			return new ValueHolder();
		}

		#region INotifyPropertyChanged Members

		public event PropertyChangedEventHandler PropertyChanged;

		protected void OnPropertyChanged(string name)
		{
			if(PropertyChanged != null)
				PropertyChanged(this, new PropertyChangedEventArgs(name));
		}

		#endregion
	}
}
