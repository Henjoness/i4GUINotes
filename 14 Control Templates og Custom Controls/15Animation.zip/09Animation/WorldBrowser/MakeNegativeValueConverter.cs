﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WorldBrowser
{
	//[ValueConversion(typeof(double), typeof(double))]
	public class GetWidthConverter : IValueConverter
	{
		public GetWidthConverter()
		{
		}

		#region IValueConverter Members

		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			ABSwitcher switcher = value as ABSwitcher;
			if (switcher != null)
				return switcher.ActualWidth;

			return 400;
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return 0;
		}

		#endregion
	}
}
