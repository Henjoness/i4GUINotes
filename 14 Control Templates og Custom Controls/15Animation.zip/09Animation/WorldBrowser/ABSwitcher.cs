﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Xml;
using System.Text;
using System.Windows.Markup;
using System.IO;
using System.Windows.Media;

namespace WorldBrowser
{
    public class ABSwitcher : ContentControl
    {
        /// <summary>Keeps track of the currently displayed element</summary>
        public enum Elements
        {
            ElementA,
            ElementB
        }

		public ABSwitcher()
		{
			//this.DataContext = this;
		}

        /// <summary>Static constructor - primarily registers dependency properties</summary>
        static ABSwitcher()
        {
            ElementAProperty = DependencyProperty.Register("ElementA", typeof(object), typeof(ABSwitcher));
            ElementBProperty = DependencyProperty.Register("ElementB", typeof(object), typeof(ABSwitcher));

            PropertyMetadata currentElementMetaData = new PropertyMetadata(Elements.ElementA,new PropertyChangedCallback(OnCurrentElementChanged));
            CurrentElementProperty = DependencyProperty.Register("CurrentElement", typeof(Elements), typeof(ABSwitcher),currentElementMetaData,null);
			//CurrentElementProperty = DependencyProperty.Register("CurrentElement", typeof(Elements), typeof(ABSwitcher));

			PropertyMetadata elementALeftMetaData = new PropertyMetadata(new PropertyChangedCallback(OnLeftAChanged));
			ElementALeftProperty = DependencyProperty.Register("ElementALeft", typeof(double), typeof(ABSwitcher), elementALeftMetaData);

			PropertyMetadata elementBLeftMetaData = new PropertyMetadata(new PropertyChangedCallback(OnLeftBChanged));
			ElementALeftProperty = DependencyProperty.Register("ElementBLeft", typeof(double), typeof(ABSwitcher), elementBLeftMetaData);
        }

		public static void OnLeftAChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
		{
			ABSwitcher switcher = dependencyObject as ABSwitcher;
			switcher.SetLeft(Elements.ElementA,e.Property, (double)e.NewValue);
		}

		public static void OnLeftBChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
		{
			ABSwitcher switcher = dependencyObject as ABSwitcher;
			switcher.SetLeft(Elements.ElementB,e.Property, (double)e.NewValue);
		}

		public void SetLeft(Elements whichElement, DependencyProperty property, double value)
		{
			FrameworkElement element = ((whichElement == Elements.ElementA) ? ElementA : ElementB) as FrameworkElement;
			if (element != null)
			{
				if (value == 1000000)
				{
					value = element.ActualWidth;
					SetValue(property, value);
					return;
				}

				Transform t = element.RenderTransform;
				if ((t == null) || ((t is MatrixTransform) && ((MatrixTransform)t).Matrix.IsIdentity))
				{
					t = new TranslateTransform(value, 0);
					element.RenderTransform = t;
				}
				else if (t is TranslateTransform)
				{
					((TranslateTransform)t).X = value;
				}
			}
		}

		/// <summary>This method will be called whenever the value of the CurrentElement property is changed</summary>
		/// <param name="dependencyObject">The object whose value has changed</param>
		/// <param name="e">Event arguments</param>
		public static void OnCurrentElementChanged(DependencyObject dependencyObject,DependencyPropertyChangedEventArgs e)
		{
		    ABSwitcher switcher = dependencyObject as ABSwitcher;
		    //switcher.UpdateResources();

			if (switcher.CurrentElement == Elements.ElementA)
			{
				RoutedEventArgs args = new RoutedEventArgs(SwitchToElementAEvent);
				switcher.RaiseEvent(args);
			}
			else
			{
				RoutedEventArgs args = new RoutedEventArgs(SwitchToElementBEvent);
				switcher.RaiseEvent(args);
			}    
		}

        public static DependencyProperty ElementAProperty;
        public static DependencyProperty ElementBProperty;
        //public static DependencyProperty FromElementProperty;
        //public static DependencyProperty ToElementProperty;
        public static DependencyProperty CurrentElementProperty;
		public static DependencyProperty ElementALeftProperty;
		public static DependencyProperty ElementBLeftProperty;

        /// <summary>The A "element" - i.e. one of the items we are possibly displaying</summary>
        public object ElementA
        {
            get { return GetValue(ElementAProperty); }
            set { SetValue(ElementAProperty, value); }
        }

        /// <summary>The B "element" - i.e. one of the items we are possibly displaying</summary>
        public object ElementB
        {
            get { return GetValue(ElementBProperty); }
            set { SetValue(ElementBProperty, value); }
        }

		public double ElementALeft
		{
			get { return (double)GetValue(ElementALeftProperty); }
			set { SetValue(ElementALeftProperty, value); }
		}

		public double ElementBLeft
		{
			get { return (double)GetValue(ElementBLeftProperty); }
			set { SetValue(ElementBLeftProperty, value); }
		}

		/// <summary>Whether we are currently displaying element A or element B</summary>
		public Elements CurrentElement
		{
			get { return (Elements)GetValue(CurrentElementProperty); }
			set { SetValue(CurrentElementProperty, value); }
		}

		/// <summary>Returns ElementA or ElementB, depending on which is selected</summary>
		public object SelectedElement
		{
			get { return (CurrentElement == Elements.ElementA) ? ElementA : ElementB; }
		}

		/// <summary>Returns ElementA or ElementB, depending on which is <i>not</i> selected</summary>
		public object UnselectedElement
		{
			get { return (CurrentElement == Elements.ElementA) ? ElementB : ElementA; }
		}

		/// <summary>Switches to the other element</summary>
		public void Switch()
		{
			if (CurrentElement == Elements.ElementA)
				CurrentElement = Elements.ElementB;
			else
				CurrentElement = Elements.ElementA;
		}

        public static readonly RoutedEvent SwitchToElementAEvent = EventManager.RegisterRoutedEvent("SwitchToElementA", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ABSwitcher));
        public static readonly RoutedEvent SwitchToElementBEvent = EventManager.RegisterRoutedEvent("SwitchToElementB", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(ABSwitcher));

        public event RoutedEventHandler SwitchToElementA
        {
            add { AddHandler(SwitchToElementAEvent, value); }
            remove { RemoveHandler(SwitchToElementAEvent, value); }
        }

        public event RoutedEventHandler SwitchToElementB
        {
            add { AddHandler(SwitchToElementBEvent, value); }
            remove { RemoveHandler(SwitchToElementBEvent, value); }
        }
    }
}
