﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace WorldBrowser
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private DictionaryLookup _lookup = null;

		private void Application_Startup(object sender, StartupEventArgs e)
		{
			_lookup = new DictionaryLookup();
		}

        /// <summary>Lookup object</summary>
        public DictionaryLookup Lookup
        {
            get { return _lookup; }
        }

        /// <summary>Access to our application object</summary>
        public static new App Current
        {
			[System.Diagnostics.DebuggerStepThrough]
            get { return (App)Application.Current; }
        }
    }
}
