﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace WorldBrowser
{
	//[ValueConversion(typeof(double), typeof(double))]
	public class ABLeftValueConverter : IValueConverter
	{
		public ABLeftValueConverter()
		{
		}

		#region IValueConverter Members

		public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			if (value != null)
			{
				string str = value.ToString();
				if (string.Compare(str, "Width", true) == 0)
					return double.PositiveInfinity;
				else if (string.Compare(str, "NegativeWidth", true) == 0)
					return double.NegativeInfinity;
			}

			return (double)value;
		}

		public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
		{
			return 0;
		}

		#endregion
	}
}
