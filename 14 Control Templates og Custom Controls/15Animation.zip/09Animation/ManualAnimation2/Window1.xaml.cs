﻿using System;
using System.Windows;
using System.Windows.Threading;

namespace ManualAnimation2
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      private long _start;
      private double _duration = 5000;
      private double _from = 9.0;
      private double _to = 18.0;
      
      public Window1()
      {
         InitializeComponent();
         DispatcherTimer timer = new DispatcherTimer();
         timer.Interval = TimeSpan.FromMilliseconds(50);
         _start = Environment.TickCount;
         timer.Tick += new EventHandler(timer_Tick);
         timer.IsEnabled = true;
      }

      void timer_Tick(object sender, EventArgs e)
      {
         long elapsed = Environment.TickCount - _start;
         if (elapsed >= _duration)
         {
            _button1.FontSize = _to;
            ((DispatcherTimer)sender).IsEnabled = false;
            return;
         }
         double increase = _to - _from;
         _button1.FontSize = _from + (increase / (_duration / elapsed));
      }
   }
}
