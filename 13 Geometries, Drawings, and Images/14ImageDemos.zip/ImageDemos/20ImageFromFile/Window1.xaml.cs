﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace ImageFromFile
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      

      public Window1()
      {
         InitializeComponent();
      }

      private void miExit_Click(object sender, RoutedEventArgs e)
      {
         Close();
      }

      private void miFileOpen_Click(object sender, RoutedEventArgs e)
      {
         var dlg = new OpenFileDialog();
         if (dlg.ShowDialog() == true)
         {
            img.Source = new BitmapImage(new Uri(dlg.FileName));
         }
      }
   }
}
