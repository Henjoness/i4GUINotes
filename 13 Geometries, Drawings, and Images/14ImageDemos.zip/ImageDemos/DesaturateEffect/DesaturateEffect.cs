﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace ShaderEffects
{
    public class DesaturateEffect : ShaderEffect {

        public DesaturateEffect()
        {
            PixelShader = _pixelShader;

            UpdateShaderValue(TextureProperty);
            UpdateShaderValue(SaturationProperty);
        }

        public static readonly DependencyProperty TextureProperty =
            RegisterPixelShaderSamplerProperty("Texture", typeof(DesaturateEffect), 0);

        public Brush Texture {
            get { return (Brush)GetValue(TextureProperty); }
            set { SetValue(TextureProperty, value); }
        }

        public static readonly DependencyProperty SaturationProperty = 
            DependencyProperty.Register("Saturation", typeof(double), typeof(DesaturateEffect), 
                                        new UIPropertyMetadata(1.0, PixelShaderConstantCallback(0)));
        public double Saturation {
            get { return (double)GetValue(SaturationProperty); }
            set { SetValue(SaturationProperty, value); }
        }

        private static readonly PixelShader _pixelShader =
            new PixelShader() { UriSource = Utils.MakePackUri("Desaturate.ps") };
    }
}