﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ImageSourcePipeline
{
   /// <summary>
   /// Interaction logic for Window1.xaml
   /// </summary>
   public partial class Window1 : Window
   {
      public Window1()
      {
         InitializeComponent();
      }

      private void Window_Loaded(object sender, RoutedEventArgs e)
      {
         BitmapFrame frame = BitmapFrame.Create(new Uri("Water lilies.jpg", UriKind.Relative));
         CroppedBitmap crop = new CroppedBitmap();
         crop.BeginInit();
         crop.Source = frame;
         crop.SourceRect = new Int32Rect(100, 150, 400, 250);
         crop.EndInit();
         FormatConvertedBitmap color = new FormatConvertedBitmap();
         color.BeginInit();
         color.Source = crop;
         color.DestinationFormat = PixelFormats.BlackWhite;
         color.EndInit();

         img.Source = color;
      }
   }
}
