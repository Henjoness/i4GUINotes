﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using System.Windows.Markup;
using System.Windows.Threading;


namespace ImageSharpening
{
    class AddPreviewPort
    {
        private static BlurPreviewCallback closeCallback;   //called on OK or Cancel
        private BitmapSource imageBms;                      //original image;
        private int imageBmsStride;
        public WriteableBitmap previewBitmap;               //writeable clone of image
        private byte[] viewBytes;           //byte array for rectangular PreviewPort from imageBytes
        private int viewStride;             //stride of viewBytes (retangle width)
        private Int32Rect viewRectangle;    //rectangle into imageBms defining viewBytes   X, Y, Width, Height

        private Window portWindow;
        private ScrollViewer scroller;
        private Slider zoomSlider, alphaSlider;
        private Button ok, cancel;
        public TextBox alphaText, zoomText;
        public Boolean exited = false;
        public Boolean doAdd = false;
        private Image blurPreviewImage;     //dupe of original image, may not be what XAML loaded/
        private float[] lValues;            //passed
        private float[] blurredLValues;     //passed
        private byte[] addedJpegBytes;     //calculated
        private float[] addedLValues;      //calculated
        private double threshHold;         //passed
        private EdgeEnhancement edgeEnhancement;    //passed

        private Point mouseDragStartPoint;
        private Point scrollStartOffset;


        // 1 image blurPreviewImage
        // 2 image sources, imageBMS and previewBitmap
        // blurPreviewImage has a writeable Bitmap (previewBitMap).  Starts off as Clone of original image
        // Scrolling view port shows orignal image.  Else blurPreviewImage shown.
        // blurPreviewIMage is not scrolled, but since in ScrollViewer, need full image.
        // Whenever viewport is changed, selected rectangle from orignalImage is copied to viewBytes then to blurPreviewImage.
        // When Blur slider changed, viewBytes is modified with new Blur n - Probably have to refetch it from Original Image.!!!!!
        // 
        // This class displays images, but blur classes work with array of floats
        // Converstions to/from image to array of floats must be done here.
        public AddPreviewPort(Image originalImage, float[] lValues, float[] blurredLValues, double threshHold, EdgeEnhancement edgeEnhancement, BlurPreviewCallback bpc)
        {
            imageBms = (BitmapSource) originalImage.Source;
            this.lValues = lValues;
            this.blurredLValues = blurredLValues;
            this.threshHold = threshHold / 255;
            this.edgeEnhancement = edgeEnhancement;
            closeCallback = bpc;


            imageBmsStride = imageBms.PixelWidth * ((imageBms.Format.BitsPerPixel + 7) / 8);
            previewBitmap = new WriteableBitmap(imageBms);
            portWindow = new Window();
            portWindow.Height = 600;
            portWindow.Width = 400;
            portWindow.Title = "Add Port";
            string dir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            FileStream s = new FileStream(dir+"\\AddPreview.xaml", FileMode.Open);
            DependencyObject rootElement = (DependencyObject)XamlReader.Load(s);
            portWindow.Content = rootElement;
            scroller = (ScrollViewer)LogicalTreeHelper.FindLogicalNode(rootElement, "scroller");
            zoomSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomSlider");
            alphaSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "AlphaSlider");
            alphaText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "AlphaText");
            zoomText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomText");
            blurPreviewImage = (Image)LogicalTreeHelper.FindLogicalNode(rootElement, "addPreviewImage");
            ok = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "OK");
            cancel = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "Cancel");

            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap
            //XAML bindings do not have converters, overwrite them
            BindIValueConverter(zoomSlider, zoomText);
            BindIValueConverter(alphaSlider, alphaText);

            portWindow.Show();


            TransformGroup tranGroup = new TransformGroup();
            ScaleTransform scaleTran = new ScaleTransform(1.0, 1.0, scroller.ExtentWidth / 2, scroller.ExtentHeight / 2);
            tranGroup.Children.Add(scaleTran);
            TranslateTransform translateTran = new TranslateTransform(0, 0);
            tranGroup.Children.Add(translateTran);
            blurPreviewImage.RenderTransform = tranGroup;

            scroller.ScrollToHorizontalOffset((scroller.ExtentWidth / 2) - (scroller.ViewportWidth / 2));
            scroller.ScrollToVerticalOffset((scroller.ExtentHeight / 2) - (scroller.ViewportHeight / 2));

            blurPreviewImage.MouseLeftButtonDown += image_MouseLeftButtonDown;
            blurPreviewImage.MouseRightButtonDown += image_MouseRightButtonDown;
            blurPreviewImage.MouseLeftButtonUp += image_MouseLeftButtonUp;
            blurPreviewImage.MouseMove += image_MouseMove;

            zoomSlider.ValueChanged += zoomSlider_ValueChanged;
            alphaSlider.ValueChanged += CheckRefresh;

            portWindow.SizeChanged += window_SizeChanged;
            portWindow.Closed += portClosed_Click;

            ok.Click += ok_Click;
            cancel.Click += cancel_Click;

            scroller.ScrollChanged += scrollerChanged;
        }


        public byte[] AddJpeg
        {
            get
            {
                return addedJpegBytes;
            }
        }


        public float[] AddedLValues
        {
            get
            {
                return addedLValues;
            }
        }


        private void BindIValueConverter(Slider srcSlider, TextBox dstTextBox)
        {
            Binding binding = new Binding();
            binding.Source = srcSlider;
            binding.Path = new PropertyPath("Value");
            binding.Mode = BindingMode.TwoWay;
            SliderConverter sliderConverter = new SliderConverter();
            binding.Converter = new SliderConverter();
            dstTextBox.SetBinding(TextBox.TextProperty, binding);
        } //BindIValueConverter()


        public void UnHide()
        {
            doAdd = false;
            this.viewRectangle = SetRectView();
            portWindow.Visibility = System.Windows.Visibility.Visible;
            portWindow.Topmost = true;
        }  //UnHide()


        public void Close()
        {
            portWindow.Close();
        }//Close()


        private float[] AddRect(Int32Rect rect)
        {
            float[] add = new float[rect.Width * rect.Height];
            int numColumns = rect.Width;
            int numRows = rect.Height;
            int lStride = imageBmsStride / 4;
            int srcIndex = rect.Y * lStride + rect.X;
            int addIndex = 0;
            double alpha = alphaSlider.Value/10;
            double diff;

            {
                for (int i=0; i<numRows; i++)
                {
                    for (int j = 0; j < numColumns; j++)
                    {
                        diff = lValues[srcIndex] - blurredLValues[srcIndex];
                        if (Math.Abs(diff) < threshHold) diff = 0;
                        else if (diff < 0 && edgeEnhancement == EdgeEnhancement.LightOnly) diff = 0;
                        else if (diff > 0 && edgeEnhancement == EdgeEnhancement.DarkOnly) diff = 0;
                        add[addIndex] = lValues[srcIndex] + (float)(alpha * diff);
                        if (add[addIndex]>1.0) add[addIndex]=1.0F;
                        if (add[addIndex]<0) add[addIndex]=0;
                        addIndex++;
                        srcIndex++;
                    }
                    srcIndex += (lStride - numColumns);
                }
            }
            addedLValues = add;     //save for later fetching
            return add;
        }  //DiffRect();


        //Copy rectangle selected pixels from ImageBms into viewBytes array
        public Int32Rect ViewRectangle
        {
            set
            {
                        viewBytes = new byte[value.Height * value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8)];
                        viewStride = value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8);
                        float[] viewLBytes = AddRect(value);
                        
                                                int viewBytesIndex = 0;
                                                for (int i = 0; i < viewLBytes.Length; i++)
                                                {
                                                    viewBytes[viewBytesIndex] = viewBytes[viewBytesIndex + 1] = viewBytes[viewBytesIndex + 2] = (byte)(viewLBytes[i] * 255);
                                                    viewBytesIndex += 4;
                                                }
                          
                    viewRectangle = value;
            }
        } // ViewRectangle Property
 

        //Updates previewBMS with rectangle selected pixels in viewBytes
        public WriteableBitmap UpdateWithView()
        {
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)
            return previewBitmap;
        }


        private void window_SizeChanged(Object sender, SizeChangedEventArgs e)
        {
            this.viewRectangle = new Int32Rect((int)scroller.HorizontalOffset, (int)scroller.VerticalAlignment,
                                               (int)scroller.ViewportWidth,    (int)scroller.ViewportHeight);
            Msg.ShowScrollerSize("Add Port resized\n", scroller);
        }


        private Int32Rect SetRectView()
        {
            Int32Rect rect = new Int32Rect();
            
            if (scroller.HorizontalOffset>=0 && scroller.HorizontalOffset<blurPreviewImage.Source.Width)
                rect.X = (int)scroller.HorizontalOffset;
            else rect.X = 0;
            if (scroller.VerticalOffset>= 0 && scroller.VerticalOffset<=blurPreviewImage.Source.Height)
                rect.Y = (int)scroller.VerticalOffset;
            else rect.Y = 0;

            rect.Width = Math.Min((int)blurPreviewImage.Source.Width - rect.X, (int)(scroller.ViewportWidth * 100 / zoomSlider.Value));
            rect.Height = Math.Min((int)blurPreviewImage.Source.Height - rect.Y, (int)(scroller.ViewportHeight * 100 / zoomSlider.Value));
            return rect;
        }


        private void scrollerChanged(object sender, ScrollChangedEventArgs e)
        {
            this.viewRectangle = SetRectView();
        } //ScrollerChanged()


        private void image_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (blurPreviewImage.Source == previewBitmap)
                blurPreviewImage.Source = imageBms;
            else
                 blurPreviewImage.Source = previewBitmap;
       }


        private void image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];
            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2 );// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = 1.0;
            zoomSlider.Value = 100;

            mouseDragStartPoint = e.GetPosition(scroller);
            scrollStartOffset.X = scroller.HorizontalOffset;
            scrollStartOffset.Y = scroller.VerticalOffset;
            blurPreviewImage.Source = imageBms;             //display orignal image

            bool x = blurPreviewImage.CaptureMouse();
        } // image_MouseLeftButtonDown()


        private void image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.ViewRectangle = viewRectangle;
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)

            if (blurPreviewImage.IsMouseCaptured)
            {
                blurPreviewImage.ReleaseMouseCapture();
            }
        } // image_MouseLeftButtonUp()


        private void image_MouseMove(object sender, MouseEventArgs e)
        {
            bool x = blurPreviewImage.IsMouseCaptured;
            if (blurPreviewImage.IsMouseCaptured)
            {
                // Get the new mouse position. 
               Point mouseDragCurrentPoint = e.GetPosition(scroller);    //should it be off portwindow or image?

                // Determine the new amount to scroll. 
                Point delta = new Point(
                    (mouseDragCurrentPoint.X > this.mouseDragStartPoint.X) ?
                    -(mouseDragCurrentPoint.X - this.mouseDragStartPoint.X) :
                    (this.mouseDragStartPoint.X - mouseDragCurrentPoint.X),
                    (mouseDragCurrentPoint.Y > this.mouseDragStartPoint.Y) ?
                    -(mouseDragCurrentPoint.Y - this.mouseDragStartPoint.Y) :
                    (this.mouseDragStartPoint.Y - mouseDragCurrentPoint.Y));

                // Scroll to the new position.
                double scrollX, scrollY;
                scrollX = this.scrollStartOffset.X + delta.X; // *100 / zoomSlider.Value;
                scrollY = this.scrollStartOffset.Y + delta.Y; // *100 / zoomSlider.Value;
                scroller.ScrollToHorizontalOffset(scrollX);
                scroller.ScrollToVerticalOffset(scrollY);
            }
        } // image_MouseMove()


        private void zoomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];

            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2);// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = e.NewValue / 100;
            if (e.NewValue < 100 && e.NewValue<e.OldValue)
            {
                Int32Rect rect = new Int32Rect();
                rect.X = (int)(sTransform.CenterX - (scroller.ViewportWidth / 2) *100 / zoomSlider.Value);
                if (rect.X < 0) rect.X = 0;
                if (rect.X > scroller.ExtentWidth) rect.X = (int)scroller.ExtentWidth;
                rect.Y = (int)(sTransform.CenterY - (scroller.ViewportHeight / 2) *100 / zoomSlider.Value);
                if (rect.Y < 0) rect.Y = 0;
                if (rect.Y > scroller.ExtentHeight) rect.Y = (int)scroller.ExtentHeight;
                rect.Width = Math.Min((int)((scroller.ViewportWidth) * 100 / zoomSlider.Value), (int)(scroller.ExtentWidth-rect.X));
                rect.Height = Math.Min((int)((scroller.ViewportHeight) * 100 / zoomSlider.Value), (int)(scroller.ExtentHeight-rect.Y));
                this.ViewRectangle = rect;
                previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            }
        } // zoomSlider_ValueChanged()


        private void CheckRefresh(object sender, RoutedEventArgs e)
        {
            this.ViewRectangle = viewRectangle;
            UpdateWithView();
        } //CheckRefresh()


        //Exit this Window by clicking OK, Cancel or exit the Window
        //OK and Cancel leave the Preview port Window hidden.
        //Exit zaps everything including DiffPreviewPort object via closeCallback()
        private void portClosed_Click(object sender, EventArgs e)
        {
            exited = true;
            closeCallback();
        } // portClosed_Click()
   

        private void ok_Click(object sender, RoutedEventArgs e)
        {
            doAdd = true;
            portWindow.Hide();
            Int32Rect wholeImage = new Int32Rect(0, 0, imageBms.PixelWidth, imageBms.PixelHeight);
            this.ViewRectangle = wholeImage;
            addedJpegBytes = viewBytes;
            closeCallback();
        } //ok_Click()


        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            portWindow.Hide();
            doAdd = false;
            closeCallback();
        } //cancel_Click()


        //recalculate the Add using passed L values from a new Blur and the passed threshHold from a new Diff
        public void recalculateAdd(float[] newLBlur, double newThresh, EdgeEnhancement edge)
        {
            blurredLValues = newLBlur;
            threshHold = newThresh/255;
            edgeEnhancement = edge;
        }


    } // class BlurPreviewPort

}