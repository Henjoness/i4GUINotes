﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;


namespace ImageSharpening
{
    static class Msg
    {
        private static ScrollViewer sv;
        private static TextBlock tb;


        static Msg()
        {
            sv = Window1.msgSv;
            tb = Window1.msgTb;
        }

        //display a msg in msg area
        public static void ShowMsg(string msg)
        {
            tb.Text += msg;
            sv.ScrollToEnd();
        } //ShowMsg()


        //display a msg followed by scrollViewer port size
        public static void ShowScrollerSize(string msg, ScrollViewer scroller)
        {
            ShowMsg(msg);
            Msg.ShowMsg("  width: " + (int)scroller.ViewportWidth + "\n  height: " + (int)scroller.ViewportHeight + "\n");
        } // ShowScrollerSize()

    }
}
