﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageSharpening
{
    static class IterativeBlur
    {
        private static float[] src;
        private static int numColumns, numRows;
        private static ProgressBarUpdateDelegate reporterCallback;

        private static double sigma;   //must be >= 0.5!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        private static double q;
        private static double b0, b1, b2, b3;
        private static double bNorm;
        private static float[] w;          //temp storage for holding forward recursive convolution

        public static double Sigma
        {
            set
            {
                sigma = value;
                q = ComputeQ(value);
                ComputeB(q);
            }
        } // set Sigma property

        
        //This is the only public procedure
        public static float[] Blur(float[] srcArray, int numColumns,
                              ProgressBarUpdateDelegate backgroundReporter)
        {
            IterativeBlur.src = srcArray;
            IterativeBlur.numColumns = numColumns;
            numRows = srcArray.Length / numColumns;
            reporterCallback = backgroundReporter;
            w = new float[srcArray.Length];
            BlurRows();
            BlurColumns();
            return w;
        }


        private static double ComputeQ(double sigma)
        {
            double computedQ;
            if (sigma >= 2.5)
            {
                computedQ = 0.98711 * sigma - 0.96330;
            }
            else
            {
                computedQ = 3.91756 - 4.14554 * Math.Sqrt(1.0 - 0.26891 * sigma);
            }
            return computedQ;
        } // ComputeQ()


        private static void ComputeB(double q)
        {
            b0 = 1.57825 + (2.44413 * q) + (1.4281 * q * q) + (0.422205 * q * q * q);
            b1 = (2.44413 * q) + (2.85619 * q * q) + (1.26661 * q * q * q);
            b2 = -((1.4281 * q * q) + (1.26661 * q * q * q));
            b3 = 0.422205 * q * q * q;
            bNorm = 1 - ((b1 + b2 + b3) / b0);
        }


        private static void BlurRow(int startIndex, int endIndex)
        {
            float fill = src[startIndex];     //fill with start of row
            //forward recursive convolution
            //first 3 values use fill
            //w[n] = bNorm*input[n] + (b1*w[n-1] + b2*w[n-2] + b3*w[n-3]) / b0
            //first 3 columns in row are on an edge, compute manually using fill
            w[startIndex] = fill;
            w[startIndex + 1] = (float)((bNorm * src[startIndex + 1]) + ((b1 * fill + b2 * fill + b3 * fill) / b0));
            w[startIndex + 2] = (float)((bNorm * src[startIndex + 2]) + ((b1 * w[startIndex + 1] + b2 * fill + b3 * fill) / b0));

            for (int i = startIndex + 3; i <= endIndex; i++)
            {
                w[i] = (float)((bNorm * src[i]) + ((b1 * w[i - 1] + b2 * w[i - 2] + b3 * w[i - 3]) / b0));
                if (w[i] > 1.0F) w[i] = 1.0F;
                if (w[i] < 0.0F) w[i] = 0.0F;
            }
            //           return;
            fill = w[endIndex];         //fill with end of row
            //backward recursive convolution
            //first 3 values use fill
            //out[n] = bNorm*w[n] + (b1*out[n+1] + b2*out[n+2] + b3*out[n+3])/b0
            //note, out[n] will be written to w[n], no temp storage needed

            //first 3 columns in row are on an edge, compute manually using fill
            //w[endIndex] is already set to fill, just need to compute 2 columns
            w[endIndex - 1] = (float)((bNorm * w[endIndex - 1]) + ((b1 * w[endIndex] + b2 * fill + b3 * fill) / b0));
            w[endIndex - 2] = (float)((bNorm * w[endIndex - 2]) + ((b1 * w[endIndex - 1] + b2 * w[endIndex] + b3 * fill) / b0));

            for (int i = endIndex - 3; i >= startIndex; i--)
            {
                w[i] = (float)((bNorm * w[i]) + ((b1 * w[i + 1] + b2 * w[i + 2] + b3 * w[i + 3]) / b0));
                if (w[i] > 1.0F) w[i] = 1.0F;
                if (w[i] < 0.0F) w[i] = 0.0F;
            }
        } // BlurRow()


        public static void BlurColumn(int startIndex, int endIndex)
        {
            float fill = w[startIndex];         //fill with start of column
            //forward recursive convolution
            //first 3 values use fill
            //w[n] = bNorm*input[n] + (b1*w[n-1] + b2*w[n-2] + b3*w[n-3]) / b0
            w[startIndex + numColumns] = (float)(bNorm * w[startIndex + numColumns] + ((b1 * w[startIndex] + b2 * fill + b3 * fill) / b0));
            w[startIndex + 2 * numColumns] = (float)(bNorm * w[startIndex + 2 * numColumns] + ((b1 * w[startIndex + numColumns] + b2 * w[startIndex] + b3 * fill) / b0));

            //forward recurse
            for (int i = startIndex + 3 * numColumns; i <= endIndex; i += numColumns)
            {
                w[i] = (float)(bNorm * w[i] + ((b1 * w[i - numColumns] + b2 * w[i - 2 * numColumns] + b3 * w[i - 3 * numColumns]) / b0));
                if (w[i] > 1.0F) w[i] = 1.0F;
                if (w[i] < 0.0F) w[i] = 0.0F;
            }

            //backward recurse
            //first 3 edge values computed manually
            //out[n] = bNorm*w[n] + (b1*out[n+1] + b2*out[n+2] + b3*out[n+3])/b0
            fill = w[endIndex];
            w[endIndex - numColumns] = (float)(bNorm * w[endIndex - numColumns] + ((b1 * w[endIndex] + b2 * fill + b3 * fill) / b0));
            w[endIndex - 2 * numColumns] = (float)(bNorm * w[endIndex - 2 * numColumns] + ((b1 * w[endIndex - numColumns] + b2 * w[endIndex] + b3 * fill) / b0));
            for (int i = endIndex - 3 * numColumns; i >= startIndex; i -= numColumns)
            {
                w[i] = (float)(bNorm * w[i] + ((b1 * w[i + numColumns] + b2 * w[i + 2 * numColumns] + b3 * w[i + 3 * numColumns]) / b0));
                if (w[i] > 1.0F) w[i] = 1.0F;
                if (w[i] < 0.0F) w[i] = 0.0F;
            }
        } //BlurColumn()


        public static void BlurRows()
        {
            int fivePercent = numRows / 10;

            for (int i = 0; i < numRows; i++)
            {
                int startIndex = i * numColumns;
                int endIndex = startIndex + numColumns - 1;
                BlurRow(startIndex, endIndex);
                if (i % fivePercent == 0 && reporterCallback != null)
                    reporterCallback(i / fivePercent * 5);
            }
        } // BlurRows()


        public static void BlurColumns()
        {
            int fivePercent = numColumns / 10;

            for (int i = 0; i < numColumns; i++)
            {
                int startIndex = i;
                int endIndex = startIndex + (numRows - 1) * numColumns;
                BlurColumn(startIndex, endIndex);
                if (i % fivePercent == 0 && reporterCallback != null)
                    reporterCallback(50 + i / fivePercent * 5);
            }
        } // BlurRows()


    }
}
