﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageSharpening
{
    abstract class Gauss
    {


        // retuns a 1D Gauss kernel with standard diviation sigma
        public static double[] GaussKernel(double sigma)
        {
            //anything beyond 3 * sigma is close to zero
            int threeSigma = (int)Math.Ceiling(3 * sigma);
            //odd size kernel, out 3*sigma both ways, plus 0 at center.
            double[] kernel = new double[2 * threeSigma + 1];
            //center plus values out to +3*sigma
            for (int i = 0; i <= threeSigma; i++)
                kernel[threeSigma + i] = DiscreteGaussValue(sigma, i);
            //reflect around center to get symetrical array values
            for (int i = 1; i <= threeSigma; i++)
                kernel[threeSigma - i] = kernel[threeSigma + i];
            //normalize kernel
            double sum = 0.0;
            for (int i = 0; i < kernel.Length; i++)
                sum += kernel[i];
            for (int i = 0; i < kernel.Length; i++)
                kernel[i] /= sum;
            return kernel;
        }


        private static double DiscreteGaussValue(double sigma, int x)
        {
            double r = x - 0.5;
            double sum = 0.0;
            for (int i = 0; i < 1000; i++)
            {
                sum += GaussValue(sigma, x + i * 0.001);
            }
            return sum / 1000;
        }


        public static double GaussValue(double sigma, double x)
        {
            return Math.Exp(-x * x / (2 * sigma * sigma));  // e^-(x^2/2sigma^2)
        }



    } // class Gauss



    class GaussKernel : Gauss
    {
        private double sigma;
        private double[] gaussKernel;

        // default is sigma=0
        public GaussKernel()
        {
            sigma = 0.0;
            gaussKernel = new double[] {0.0, 1.0, 0.0};
        }

        public GaussKernel(double sigma)
        {
            gaussKernel = GaussKernel(sigma);
            this.sigma = sigma;
        }


        public double Sigma
        {
            set
            {
                if (value > 0.0)
                {
                    gaussKernel = GaussKernel(value);
                    sigma = value;
                }
            }
            get
            {
                return sigma;
            }
        } //sigma accessor


        public double[] Kernel
        {
            get
            {
                return gaussKernel;
            }
        } //gausKernel accessor
} // class GaussKernel
}
