﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using System.Windows.Markup;
using System.Windows.Threading;


namespace ImageSharpening
{
    class BlurPreviewPort
    {
        private static BlurPreviewCallback closeCallback;   //called on OK or Cancel
        public ProgressBarUpdateDelegate MainThreadUIUpdate;//
        private BitmapSource imageBms;                      //original image;
        private int imageBmsStride;
        public WriteableBitmap previewBitmap;               //writeable clone of image
        private byte[] viewBytes;           //byte array for rectangular PreviewPort from imageBytes
        private int viewStride;             //stride of viewBytes (retangle width)
        private Int32Rect viewRectangle;    //rectangle into imageBms defining viewBytes   X, Y, Width, Height

        private Window portWindow;
        private ScrollViewer scroller;
        private Slider blurSlider, zoomSlider;
        private Point lastZoomPoint;
        private Button ok, cancel;
        private RadioButton standGauss, iterGauss;
        public TextBox blurText, zoomText;
        public Boolean doBlur = false;
        public Boolean exited = false;
        public double blurValue = 1.0;
        private Image blurPreviewImage;     //dupe of original image, may not be what XAML loaded/
        private float[] lValues;
        private float[] blurredLValues;
        private BlurFloatArray blurFloatArray;

        private Point mouseDragStartPoint;
        private Point scrollStartOffset;


        private Border border;

        // 1 image blurPreviewImage
        // 2 image sources, imageBMS and previewBitmap
        // blurPreviewImage has a writeable Bitmap (previewBitMap).  Starts off as Clone of original image
        // Scrolling view port shows orignal image.  Else blurPreviewImage shown.
        // blurPreviewIMage is not scrolled, but since in ScrollViewer, need full image.
        // Whenever viewport is changed, selected rectangle from orignalImage is copied to viewBytes then to blurPreviewImage.
        // When Blur slider changed, viewBytes is modified with new Blur n - Probably have to refetch it from Original Image.!!!!!
        // 
        // This class displays images, but blur classes work with array of floats
        // Converstions to/from image to array of floats must be done here.
        public BlurPreviewPort( Image originalImage, float[] lValues, BlurPreviewCallback bpc)
        {
            imageBms = (BitmapSource) originalImage.Source;
            this.lValues = lValues;
            closeCallback = bpc;
            blurFloatArray = new BlurFloatArray(lValues, imageBms.PixelWidth);

            imageBmsStride = imageBms.PixelWidth * ((imageBms.Format.BitsPerPixel + 7) / 8);
            previewBitmap = new WriteableBitmap(imageBms);
            portWindow = new Window();
            portWindow.Height = 600;
            portWindow.Width = 400;
            portWindow.Title = "Blur Port";
            string dir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            FileStream s = new FileStream(dir+"\\BlurPreview.xaml", FileMode.Open);
            DependencyObject rootElement = (DependencyObject)XamlReader.Load(s);
            portWindow.Content = rootElement;
            scroller = (ScrollViewer)LogicalTreeHelper.FindLogicalNode(rootElement, "scroller");
            blurSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "BlurSlider");
            zoomSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomSlider");
            blurText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "BlurText");
            zoomText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomText");
            blurPreviewImage = (Image)LogicalTreeHelper.FindLogicalNode(rootElement, "blurPreviewImage");
            ok = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "OK");
            cancel = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "Cancel");
            standGauss = (RadioButton)LogicalTreeHelper.FindLogicalNode(rootElement, "StandGauss");
            iterGauss = (RadioButton)LogicalTreeHelper.FindLogicalNode(rootElement, "IterGaussButton");   //not Working

            border = (Border)LogicalTreeHelper.FindLogicalNode(rootElement, "Border");   //not Working

            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap
            //XAML bindings do not have converters, overwrite them
            BindIValueConverter(zoomSlider, zoomText);
            BindIValueConverter(blurSlider, blurText);
            portWindow.Show();


            TransformGroup tranGroup = new TransformGroup();
            ScaleTransform scaleTran = new ScaleTransform(1.0, 1.0, scroller.ExtentWidth / 2, scroller.ExtentHeight / 2);
            tranGroup.Children.Add(scaleTran);
            TranslateTransform translateTran = new TranslateTransform(0, 0);
            tranGroup.Children.Add(translateTran);
            blurPreviewImage.RenderTransform = tranGroup;

            scroller.ScrollToHorizontalOffset((scroller.ExtentWidth / 2) - (scroller.ViewportWidth / 2));
            scroller.ScrollToVerticalOffset((scroller.ExtentHeight / 2) - (scroller.ViewportHeight / 2));

            lastZoomPoint.X = ((scroller.ExtentWidth / 2) - (scroller.ViewportWidth / 2)); ;
            lastZoomPoint.Y = ((scroller.ExtentHeight / 2) - (scroller.ViewportHeight / 2));

            blurPreviewImage.MouseLeftButtonDown += image_MouseLeftButtonDown;
            blurPreviewImage.MouseRightButtonDown += image_MouseRightButtonDown;
            blurPreviewImage.MouseLeftButtonUp += image_MouseLeftButtonUp;
            blurPreviewImage.MouseMove += image_MouseMove;

            zoomSlider.ValueChanged += zoomSlider_ValueChanged;
            blurSlider.ValueChanged += blurSlider_ValueChanged;

            portWindow.SizeChanged += window_SizeChanged;
            portWindow.Closed += portClosed_Click;

            ok.Click += ok_Click;
            cancel.Click += cancel_Click;

            standGauss.Checked += chooseStandGauss;
            iterGauss.Checked += chooseIterGauss;

            scroller.ScrollChanged += scrollerChanged;
        }


        private void BindIValueConverter(Slider srcSlider, TextBox dstTextBox)
        {
            Binding binding = new Binding();
            binding.Source = srcSlider;
            binding.Path = new PropertyPath("Value");
            binding.Mode = BindingMode.TwoWay;
            SliderConverter sliderConverter = new SliderConverter();
            binding.Converter = new SliderConverter();
            dstTextBox.SetBinding(TextBox.TextProperty, binding);
        } //BindIValueConverter()


        public void UnHide()
        {
            doBlur = false;
            portWindow.Visibility = System.Windows.Visibility.Visible;
            portWindow.Topmost = true;
        }


        public void Close()
        {
            portWindow.Close();
        }


        //return the blurred l values
        public float[] BlurredLValues
        {
            get
            {
                return blurredLValues;
            }
        }


        //Copy rectangle selected pixels from ImageBms into viewBytes array
        public Int32Rect ViewRectangle
        {
            set
            {
                        viewBytes = new byte[value.Height * value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8)];
                        viewStride = value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8);
                        float[] viewLBytes = blurFloatArray.BlurRect(value);
                        int viewBytesIndex = 0;
                        for (int i = 0; i < viewLBytes.Length; i++)
                        {
                            viewBytes[viewBytesIndex] = viewBytes[viewBytesIndex + 1] = viewBytes[viewBytesIndex + 2] = (byte)(viewLBytes[i] * 255);
                            viewBytesIndex += 4;
                        }
                    viewRectangle = value;
            }
        } // ViewRectangle Property
 

        //called by BlurAllValues as it works to indicate progress.
        //in same thread as BlurAllValues!
        public void BlurAllValuesCallback(int percent)
        {
            //update the main thread
            portWindow.Dispatcher.BeginInvoke(DispatcherPriority.Send, MainThreadUIUpdate, (int) (percent * .95));
        }


        public void BlurAllValues(ref byte[] dst)
        {
            blurredLValues =  blurFloatArray.Blur(BlurAllValuesCallback);  //!NOT STORED FOR LATER USE!!!!!!!!!!!!!!!!!!!!!!!!!!
            byte[] lJpeg = new byte[lValues.Length * 4];
            int jpegIndex = 0;
            for (int lIndex = 0; lIndex < lValues.Length; lIndex++)
            {
                lJpeg[jpegIndex] = lJpeg[jpegIndex + 1] = lJpeg[jpegIndex + 2] = (byte)(blurredLValues[lIndex] * 255);
                jpegIndex += 4;
            }
            dst = lJpeg;
            //tell main thread blur is done
            portWindow.Dispatcher.BeginInvoke(DispatcherPriority.Send, MainThreadUIUpdate, 100 );
        }


        //Updates previewBMS with rectangle selected pixels in viewBytes
        public WriteableBitmap UpdateWithView()
        {
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)
            return previewBitmap;
        }


        private void window_SizeChanged(Object sender, SizeChangedEventArgs e)
        {
            this.viewRectangle = new Int32Rect((int)scroller.HorizontalOffset, (int)scroller.VerticalAlignment,
                                               (int)scroller.ViewportWidth,    (int)scroller.ViewportHeight);
            Msg.ShowScrollerSize("Blur Port resized\n", scroller);
        } // window_SizeChanged()


        //PROBABLY WILL NOT NEED THIS ANYMORE!!!
        private Int32Rect SetRectView()
        {
            Int32Rect rect = new Int32Rect();
            
            if (scroller.HorizontalOffset>=0 && scroller.HorizontalOffset<blurPreviewImage.Source.Width)
                rect.X = (int)scroller.HorizontalOffset;
            else rect.X = 0;
            if (scroller.VerticalOffset>= 0 && scroller.VerticalOffset<=blurPreviewImage.Source.Height)
                rect.Y = (int)scroller.VerticalOffset;
            else rect.Y = 0;

            rect.Width = Math.Min((int)blurPreviewImage.Source.Width - rect.X, (int)(scroller.ViewportWidth * 100 / zoomSlider.Value));
            rect.Height = Math.Min((int)blurPreviewImage.Source.Height - rect.Y, (int)(scroller.ViewportHeight * 100 / zoomSlider.Value));
            return rect;
        }


        private void scrollerChanged(object sender, ScrollChangedEventArgs e)
        {
            this.viewRectangle = SetRectView();
        } //ScrollerChanged()


        private void image_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (blurPreviewImage.Source == previewBitmap)
                blurPreviewImage.Source = imageBms;
            else
                 blurPreviewImage.Source = previewBitmap;
       }


        private void image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];
            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2 );// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = 1.0;
            zoomSlider.Value = 100;

            mouseDragStartPoint = e.GetPosition(scroller);
            scrollStartOffset.X = scroller.HorizontalOffset;
            scrollStartOffset.Y = scroller.VerticalOffset;
            blurPreviewImage.Source = imageBms;             //display orignal image

            bool x = blurPreviewImage.CaptureMouse();
        } // image_MouseLeftButtonDown()


        private void image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.ViewRectangle = viewRectangle;
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)

            if (blurPreviewImage.IsMouseCaptured)
            {
                //               this.Cursor = Cursors.Arrow;
                blurPreviewImage.ReleaseMouseCapture();
            }
        } // image_MouseLeftButtonUp()


        private void image_MouseMove(object sender, MouseEventArgs e)
        {
            bool x = blurPreviewImage.IsMouseCaptured;
            if (blurPreviewImage.IsMouseCaptured)
            {
                // Get the new mouse position. 
               Point mouseDragCurrentPoint = e.GetPosition(scroller);    //should it be off portwindow or image?

                // Determine the new amount to scroll. 
                Point delta = new Point(
                    (mouseDragCurrentPoint.X > this.mouseDragStartPoint.X) ?
                    -(mouseDragCurrentPoint.X - this.mouseDragStartPoint.X) :
                    (this.mouseDragStartPoint.X - mouseDragCurrentPoint.X),
                    (mouseDragCurrentPoint.Y > this.mouseDragStartPoint.Y) ?
                    -(mouseDragCurrentPoint.Y - this.mouseDragStartPoint.Y) :
                    (this.mouseDragStartPoint.Y - mouseDragCurrentPoint.Y));

                // Scroll to the new position.
                double scrollX, scrollY;
                scrollX = this.scrollStartOffset.X + delta.X; // *100 / zoomSlider.Value;
                scrollY = this.scrollStartOffset.Y + delta.Y; // *100 / zoomSlider.Value;
                scroller.ScrollToHorizontalOffset(scrollX);
                scroller.ScrollToVerticalOffset(scrollY);
            }
        } // image_MouseMove()


        private void zoomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];

            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2);// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = e.NewValue / 100;
            if (e.NewValue < 100 && e.NewValue<e.OldValue)
            {
                Int32Rect rect = new Int32Rect();
                rect.X = (int)(sTransform.CenterX - (scroller.ViewportWidth / 2) *100 / zoomSlider.Value);
                if (rect.X < 0) rect.X = 0;
                if (rect.X > scroller.ExtentWidth) rect.X = (int)scroller.ExtentWidth;
                rect.Y = (int)(sTransform.CenterY - (scroller.ViewportHeight / 2) *100 / zoomSlider.Value);
                if (rect.Y < 0) rect.Y = 0;
                if (rect.Y > scroller.ExtentHeight) rect.Y = (int)scroller.ExtentHeight;
                rect.Width = Math.Min((int)((scroller.ViewportWidth) * 100 / zoomSlider.Value), (int)(scroller.ExtentWidth-rect.X));
                rect.Height = Math.Min((int)((scroller.ViewportHeight) * 100 / zoomSlider.Value), (int)(scroller.ExtentHeight-rect.Y));
                this.ViewRectangle = rect;
                previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            }
        } // zoomSlider_ValueChanged()


        private void blurSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            blurFloatArray.Sigma = blurSlider.Value;
            this.ViewRectangle = viewRectangle;
            UpdateWithView();
        }


        private void chooseStandGauss(object sender, RoutedEventArgs e)
        {
            blurFloatArray.Method = 0;
            blurFloatArray.Sigma = blurSlider.Value;
        }


        private void chooseIterGauss(object sender, RoutedEventArgs e)
        {
            blurFloatArray.Method = 1;
            blurFloatArray.Sigma = blurSlider.Value;
        } //chooseIterGauss()


        //Exit this Window by clicking OK, Cancel or exit the Window
        //OK and Cancel leave the Preview port Window hidden.
        //Exit zaps everything including DiffPreviewPort object via closeCallback()
        private void portClosed_Click(object sender, EventArgs e)
        {
            exited = true;
            closeCallback();
        } // portClosed_Click()


        private void ok_Click(object sender, RoutedEventArgs e)
        {
            blurValue = blurSlider.Value;
            doBlur = true;
            portWindow.Hide();
            closeCallback();
        } //ok_Click()


        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            blurValue = 1.0;
            portWindow.Hide();
            doBlur = false;
            closeCallback();
        } //cancel_Click()
    } // class BlurPreviewPort





    //The Blur and Zoom sliders should use ints not doubles
    class SliderConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //Convert double to an int
            double d = (double)value;
            return (int)d;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            return value;
        }
    } // class SliderConverter
}