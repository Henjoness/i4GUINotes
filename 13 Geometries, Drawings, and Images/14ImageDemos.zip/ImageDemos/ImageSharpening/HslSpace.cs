﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageSharpening
{
    enum RGB { Blue, Green, Red };
    enum HSL { Hue, Saturation, Lightness };
 
    
    // static methods for converting an array of rgb to hsl and hsl to rgb
    // the enumS HSL and RGB are used to define element order within the HSL and RGB arrays
    //both methods take an input array and return the converted array. 
    //NOTE, returned hsl is an array of floats all values between 0 and 1.
    class HslSpace
    {
        //convert RGB To HSL
        //0.0 <= H,S,L <= 1.0 
        static public float[] RgbToHsl(byte[] rgb)
        {
            float[] hsl = new float[rgb.Length];   //Array of float for HSL values (0.0 to 1.0)
            for (int i = 0; i < rgb.Length; i += 4)
            {
                float var_R = (float)(rgb[i + (int)RGB.Red] / 255.0);              //nomalized RGB values, 0 to 1.0
                float var_G = (float)(rgb[i + (int)RGB.Green] / 255.0);
                float var_B = (float)(rgb[i + (int)RGB.Blue] / 255.0);

                float var_Min = Math.Min(Math.Min(var_R, var_G), var_B);  //Min. value of RGB
                float var_Max = Math.Max(Math.Max(var_R, var_G), var_B);  //Max. value of RGB
                float del_Max = var_Max - var_Min;                          //Delta RGB value

                float l = (float)((var_Max + var_Min) / 2.0);
                hsl[i + (int)HSL.Lightness] = l;

                if (del_Max == 0)       //This is a gray, no chroma...
                {
                    hsl[i + (int)HSL.Hue] = hsl[i + (int)HSL.Saturation] = 0;
                }
                else                      //Chromatic data...
                {
                    if (l < 0.5) hsl[i + (int)HSL.Saturation] = del_Max / (var_Max + var_Min);
                    else hsl[i + (int)HSL.Saturation] = (float)(del_Max / (2.0 - var_Max - var_Min));

                    float del_R = (((var_Max - var_R) / 6) + (del_Max / 2)) / del_Max;
                    float del_G = (((var_Max - var_G) / 6) + (del_Max / 2)) / del_Max;
                    float del_B = (((var_Max - var_B) / 6) + (del_Max / 2)) / del_Max;

                    if (var_R == var_Max) hsl[i + (int)HSL.Hue] = del_B - del_G;
                    else if (var_G == var_Max) hsl[i + (int)HSL.Hue] = (float)(1.0 / 3) + del_R - del_B;
                    else if (var_B == var_Max) hsl[i + (int)HSL.Hue] = (float)(2.0 / 3) + del_G - del_R;

                    if (hsl[i + (int)HSL.Hue] < 0) hsl[i + (int)HSL.Hue] += 1.0F;
                    if (hsl[i + (int)HSL.Hue] > 1) hsl[i + (int)HSL.Hue] -= 1.0F;
                }  //else chromatic data
            } //for

            return hsl;
        } // RgbToHsl()

        
        //onlu called by HslToRgb()
        static private float Hue_2_Rgb(float v1, float v2, float vH)             //Function Hue_2_RGB
        {
            if (vH < 0) vH += 1.0F;
            if (vH > 1) vH -= 1.0F;
            if ((6 * vH) < 1) return (v1 + (v2 - v1) * 6 * vH);
            if ((2 * vH) < 1) return (v2);
            if ((3 * vH) < 2) return (v1 + (v2 - v1) * ((float)(2.0 / 3.0) - vH) * 6);
            return (v1);
        } // Hue_2_Rgb()


        //Convert hsl to rgb
        //hsl input values 0.0 to 1.0
        //rgb output values 0 to 255
        static public byte[] HslToRgb(float[] hsl)
        {
            byte[] rgb = new byte[hsl.Length];   //Array of byte for RGB values
            for (int i = 0; i < hsl.Length; i += 4)
            {
                float hue = hsl[i + (int)HSL.Hue];
                float saturation = hsl[i + (int)HSL.Saturation];
                float lightness = hsl[i + (int)HSL.Lightness];
                //if Saturation=0 -> gray, set R=G=B to HSL Lightness 
                if (saturation == 0.0)
                {
                    rgb[i + (int)RGB.Red] = rgb[i + (int)RGB.Green] = rgb[i + (int)RGB.Blue] = (byte)(lightness * 255);
                }
                else
                {
                    float var1, var2;
                    if (lightness < 0.5) var2 = lightness * (float)(1.0 + saturation);
                    else var2 = (lightness + saturation) - (saturation * lightness);

                    var1 = 2 * lightness - var2;

                    rgb[i + (int)RGB.Red] = (byte)(255 * Hue_2_Rgb(var1, var2, hue + (float)(1.0 / 3.0)));
                    rgb[i + (int)RGB.Green] = (byte)(255 * Hue_2_Rgb(var1, var2, hue));
                    rgb[i + (int)RGB.Blue] = (byte)(255 * Hue_2_Rgb(var1, var2, hue - (float)(1.0 / 3.0)));
                }
            } //for
            return rgb;
        } //HslToRgb()


    }
}
