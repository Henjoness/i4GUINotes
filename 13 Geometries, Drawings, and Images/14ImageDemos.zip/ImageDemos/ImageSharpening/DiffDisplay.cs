﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageSharpening
{
    class DiffDisplay
    {
        private float[] lSrc;       // of L
        private byte[] graySrc;     // convert L to byte 
        private byte[] display;     // grayscale out
        private byte max;           // highest gray value in src
        private byte threshHold;    // gray below this value are set to black
        private int brightness;     // bump nonblack values by this amount
        private byte[] lut = new byte[256];      //look up table

        
        public DiffDisplay(float[] src)
        {
            this.lSrc = src;
            graySrc = new byte[lSrc.Length];
            display = new byte[lSrc.Length * 4];
            for (int i = 0; i < lut.Length; i++)
                lut[i] = (byte) i;   //init to identity lut
            for (int i = 0; i < lSrc.Length; i++)               //init graySrc, display and max
            {
                graySrc[i] = (byte)(lSrc[i] * 255.0);
                if (graySrc[i]>max) max=graySrc[i];
                display[i*4] = display[i*4+1] = display[i*4+2] = graySrc[i];
            }
        } // constructor

        public byte[] Display
        {
            get
            {
                return display;
            }
        }
        public float[] LSrc
        {
            set
            {
                if (lSrc.Length != value.Length)
                {
                    graySrc = new byte[value.Length];
                    display = new byte[value.Length*4];
                }

                max = 0;
                lSrc = value;
                for (int i = 0; i < lSrc.Length; i++)               //init graySrc and get max
                {
                    graySrc[i] = (byte)(lSrc[i] * 255.0);
                    if (graySrc[i] > max) max = graySrc[i];
                }
                UpdateLut();
                UpdateDisplay();
            } //set Lsrc property
        }

        public int Brightness
        {
            set
            {
                brightness = value;
            }
        }


        public byte ThreshHold
        {
            set
            {
                threshHold = value;
                UpdateLut();
                UpdateDisplay();

            }
        }


        private void UpdateLut()
        {
            //y = slope*x + b
            double slope = (255.0 - max) / (max - threshHold);
            double b = (1 - slope) * threshHold;
            for (int i = 0; i < threshHold; i++)
                lut[i] = 0;
            for (int i = threshHold; i < 256; i++)
                lut[i] = (byte) (slope * i + b);
        }  //UpdateLut()


        private void UpdateDisplay()
        {
            int displayIndex = 0;
            int pixel;
            for (int i = 0; i < graySrc.Length; i++)
            {
                pixel = lut[graySrc[i]];
                if (pixel > 0) pixel += brightness;
                if (pixel > 255) pixel = 255;
                display[displayIndex] = display[displayIndex+1] = display[displayIndex+2] = (byte) pixel;
                displayIndex+=4;
            }
        } //UpdateDisplay()


    } // Class DiffDisplay

} // Namespace WpfApplication1
