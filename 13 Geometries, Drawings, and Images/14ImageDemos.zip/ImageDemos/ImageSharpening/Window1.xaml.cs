﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Windows.Threading;
using System.Threading;
using System.ComponentModel;

namespace ImageSharpening
{
            public delegate void BlurPreviewCallback();         //routine to be called when preview window closes (OK or Cancel)
            public delegate void ProgressBarUpdateDelegate(int a);
            public enum BlurMethod {StandardGauss, IterativeGauss};
            public enum EdgeEnhancement { LightAndDark, LightOnly, DarkOnly };


    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public static TextBlock msgTb;
        public static ScrollViewer msgSv;
        // when a button is clicked, rgbIMage is updated with a one of the sources(Bms) below
        // The Bms's below serve as a cache for the button filters.  They are null till computed.
        public ProgressBarUpdateDelegate PBrUpdateDelegate;// = new ProgressBarUpdateDelegate(ProgressBarUpdate);
        private BitmapSource rgbBms;
        private BitmapSource lBms;
        private BitmapSource blurBms;
        private BitmapSource diffBms;
        private BitmapSource addBms;
        private BitmapSource sharpenBms;

        //incrementing counters every time an add or sharpen is completed.
        private int lastAddId;          
        private int lastSharpenId;

        public enum CMYK { Cyan, Magenta, Yellow, Black };
        public enum RGB { Blue, Green, Red };
        public enum HSL { Hue, Saturation, Lightness };

        
        //NOTE, only rgbValues is guaranteed to always be available
        //cmykValues and hslValues are computed only when needed.
        //The arrays contain the original data from the last picture loaded
        private  byte[] rgbValues;  //storage for actual RGB  data (value range 0-255)   
        private float[] hslValues;  //storage for actual HSL  data (value range 0.0 to 1.0)
        private float[] lValues;    //just the l channel

        private byte[] blurredJpeg; 

        private BlurPreviewPort blurPreview;
        private DiffPreviewPort diffPreview;
        private AddPreviewPort addPreview;




        public Window1()
        {
            InitializeComponent();
            this.Closing += CloseAllWindows;
            msgSv = textBoxScrollViewer;
            msgTb = tb1;
        }


        private void CloseAllWindows( Object sender, CancelEventArgs e)
        {
            if (blurPreview != null)
                blurPreview.Close();
            if (diffPreview != null)
                diffPreview.Close();
            if (addPreview != null)
                addPreview.Close();
        }


        public void ChangeTo96Dpi(Image image)
        {
            BitmapSource oldBms = (BitmapSource)image.Source;  //get existng images BitmapSource
            int stride = oldBms.PixelWidth * ((oldBms.Format.BitsPerPixel + 7) / 8);    //calculate its stride
            rgbValues = new byte[oldBms.PixelHeight * stride];   //alloc space for existing image data
            oldBms.CopyPixels(rgbValues, stride, 0);                    //get the existing rgb data
            hslValues = HslSpace.RgbToHsl(rgbValues);             //convert it to HSL
            //create a L channel array
            lValues = new float[hslValues.Length / 4];
            int lIndex = 0;
            for (int hslIndex = 0; hslIndex < hslValues.Length; hslIndex += 4)
                lValues[lIndex++] = hslValues[hslIndex + (int)HSL.Lightness];

            //using existing data, create a new BitmapSource at 96 DPI
            BitmapSource newBms = BitmapSource.Create(oldBms.PixelWidth, oldBms.PixelHeight,
                96.0, 96.0,
                oldBms.Format,
                null,
                rgbValues,
                stride);
            image.Source = newBms;  //set image source to new BitmapSource

        }


        private void ShowMsg(string msg)
        {
            tb1.Text += msg;
            this.textBoxScrollViewer.ScrollToEnd();
        } //ShowMsg()


        private void RGB_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text += "RGB clicked\n";
            tb1.Text += String.Format("PixelHeight: {0}\nPixelWidth: {1}\n",
                ((BitmapSource)this.rgbImage.Source).PixelHeight,
                ((BitmapSource)this.rgbImage.Source).PixelWidth);
            tb1.Text += String.Format("ZOOM: {0:0%}\n",
            this.rgbImage.ActualWidth / ((BitmapSource)this.rgbImage.Source).Width * 96 / ((BitmapSource)this.rgbImage.Source).DpiX);
            this.textBoxScrollViewer.ScrollToEnd();
            this.rgbImage.Source = rgbBms;
        }


        private void L_Click(object sender, RoutedEventArgs e)
        {
            ShowMsg("Lightness clicked\n");
            this.rgbImage.Source = lBms;
        }


       //excuted when OK or Cancel clicked in BlurPreviewPort
        private void Blur_Click_Callback()
        {
            if (blurPreview.exited == true)
                PreviewWindowExited("Blur");

           else if (blurPreview.doBlur == true)
            {
                ShowMsg(" Background Blur\nin progress\n Please be patient\n");
                PbarPopup.IsOpen = true;
                PBar.Value = 0;
                blurPreview.MainThreadUIUpdate = new ProgressBarUpdateDelegate(ProgressBarUpdate);
                BlurBackgroundDelegate blurDelegate = new BlurBackgroundDelegate(BlurInBackground);
                blurDelegate.BeginInvoke(null, null);   //do blur on another thread
            }
        } // Blur_Click_Callback()


        private void BlurInBackground()
        {
            blurPreview.BlurAllValues(ref blurredJpeg);     //blur the image in background & set blurredJpeg to blurred output
        }


        private void Blur_Click(object sender, RoutedEventArgs e)
        {
            if (blurBms != null)
                this.rgbImage.Source = blurBms;
            if (blurPreview == null)
                blurPreview = new BlurPreviewPort(rgbImage, lValues, Blur_Click_Callback);
            else blurPreview.UnHide();
        }


        private delegate void BlurBackgroundDelegate();
        private delegate void BlurUiDelegate();


        public void ProgressBarUpdate( int value)
        {
            PbarPopup.IsOpen = true;
            PBar.Value = value;
            if (value == 100)
            {
                blurBms = BmsEngine.CloneBms(blurredJpeg);  //blurBms must be created in UI thread not background thread!
                PbarPopup.IsOpen = false;
                this.rgbImage.Source = blurBms;
                if (diffPreview != null)
                    diffPreview.recalculateDiff(blurPreview.BlurredLValues);
                if (addPreview != null)
                    addPreview.recalculateAdd(blurPreview.BlurredLValues, diffPreview.ThreshHold, diffPreview.EdgeEnhancement);
                ShowMsg("Blur completed\n");
            }
        }


        private void Diff_Click(object sender, RoutedEventArgs e)
        {
            ShowMsg("Diff clicked\n");
            if (diffBms != null)
                this.rgbImage.Source = diffBms;
           if (blurBms == null)
            {
                ShowMsg("Diff ERROR\nNo blur has been completed.\n");
                return;
            }
            if (diffPreview == null)
                diffPreview = new DiffPreviewPort(rgbImage, lBms, lValues, blurPreview.BlurredLValues, Diff_Click_Callback);
            else diffPreview.UnHide();
 }


        //a Preview Window has been Exited by the operator.
        //null out the Preview instance variable and the BMS variable associated with the window
        private void PreviewWindowExited( string windowId)
        {
            switch( windowId)
            {
                case "Blur":
                    blurPreview = null;
                    blurBms = null;
                    break;
                case "Diff":
                    diffPreview = null;
                    diffBms = null;
                    break;
                case "Add":
                    addPreview = null;
                    addBms = null;
                    break;
            } // switch
            ShowMsg(windowId + " exited\n");
        }  //PreviewWindowExited()


        //Diff completed
        private void Diff_Click_Callback()
        {
            //has user exited the window?
            if (diffPreview.exited == true)
                PreviewWindowExited("Diff");

            else if (diffPreview.doDiff == true)
            {
                diffBms = BmsEngine.CloneBms(diffPreview.DiffJpeg);
                this.rgbImage.Source = diffBms;
                if (addPreview != null)
                    addPreview.recalculateAdd(blurPreview.BlurredLValues, diffPreview.ThreshHold, diffPreview.EdgeEnhancement);
                ShowMsg("Diff completed\n");
            }
            else ShowMsg("Diff canceled\n");
        } // Diff_Click_Callback()


        private void Add_Click(object sender, RoutedEventArgs e)
        {
            ShowMsg("Add clicked\n");
            if (addBms == null)
                this.rgbImage.Source = lBms;    //no previous add, show L values
            else this.rgbImage.Source = addBms; //show previous add
            if (diffBms == null)
            {
                ShowMsg("Add ERROR\nNo Diff has been completed.\n");
                return;
            }
            if (addPreview == null)
                addPreview = new AddPreviewPort(rgbImage, lValues, blurPreview.BlurredLValues, diffPreview.ThreshHold, diffPreview.EdgeEnhancement, Add_Click_Callback);
            else addPreview.UnHide();
     } // Add_Click()


        private void Add_Click_Callback()
        {
            //has user exited the window?
            if (addPreview.exited == true)
                PreviewWindowExited("Add");

            else if (addPreview.doAdd == true)
            {
                addBms = BmsEngine.CloneBms(addPreview.AddJpeg);
                this.rgbImage.Source = addBms;
                lastAddId++;
                ShowMsg("Add completed\n");
            }
            else ShowMsg("Add canceled\n");
        }  // Add_Click_Callback()


        private void Sharpen_Click(object sender, RoutedEventArgs e)
        {
            ShowMsg("Sharpen clicked\n");
            if (addBms == null)
            {
                ShowMsg("Sharpen ERROR\nNo Add has been completed.\n");
                return;
            }

            if (sharpenBms == null || lastSharpenId<lastAddId)
            {
                float[] addedL = addPreview.AddedLValues;
                float[] newHsl = new float[hslValues.Length];
                for (int i = 0; i < addedL.Length; i++)
                {
                    newHsl[i * 4 + (int)HSL.Hue] = hslValues[i * 4 + (int)HSL.Hue];
                    newHsl[i * 4 + (int)HSL.Saturation] = hslValues[i * 4 + (int)HSL.Saturation];
                    newHsl[i * 4 + (int)HSL.Lightness] = addedL[i];
                }
                byte[] newRgb = HslSpace.HslToRgb(newHsl);
                sharpenBms = BmsEngine.CloneBms(newRgb);
                lastSharpenId++;
            }
            this.rgbImage.Source = sharpenBms;
            ShowMsg("Sharpen completed\n");
        } //Sharpen_Click()





        //--------------------------------------------------------------------

        private void Uncache()
        {
            CloseAllWindows(null, null);
            blurBms = diffBms = addBms = sharpenBms = null;
            blurPreview = null;
            diffPreview = null;
            addPreview = null;
            lastAddId = lastSharpenId = 0;
        }


        private void FileOpen_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog oDialog = new OpenFileDialog();
            oDialog.Title = "Select a JPEG file to open";
            if ((bool)oDialog.ShowDialog())
            {
                BitmapDecoder decoder = BitmapDecoder.Create(
                    new Uri(oDialog.FileName, UriKind.Absolute),
                            BitmapCreateOptions.None,
                            BitmapCacheOption.Default);

                BitmapSource bitmapSource = decoder.Frames[0];
                this.rgbImage.Source = rgbBms = bitmapSource;
                ChangeTo96Dpi(rgbImage);
                BmsEngine.Init((BitmapSource)rgbImage.Source);

                rgbValues = BmsEngine.GetRgbData();
                byte[] newJpegBytes = new byte[BmsEngine.dataLength];
                for (int i = 0; i < BmsEngine.dataLength; i += 4)
                {
                    newJpegBytes[i + (int)RGB.Red] = newJpegBytes[i + (int)RGB.Green] = newJpegBytes[i + (int)RGB.Blue] = (byte)(hslValues[i + (int)HSL.Lightness] * 255);
                }
                lBms = BmsEngine.CloneBms(newJpegBytes);

                Uncache(); //uncache everything
                ShowMsg("New JPEG file loaded.\n");
                //No LBMS or LVALUES??  Also at 300DPI
            }
        } // FileOpen_Click()


        private void FileSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog sDialog = new SaveFileDialog();
            sDialog.Title = "Save display as a JPEG file";
            sDialog.ShowDialog();
            FileStream stream = new FileStream(sDialog.FileName, FileMode.Create);
            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.QualityLevel = 70;
            encoder.Frames.Add(BitmapFrame.Create((BitmapSource)this.rgbImage.Source));
            encoder.Save(stream);
            stream.Close();
        } //FileSave_Click()


        void OnLoad(object sender, RoutedEventArgs e)
        {
            ShowMsg("\nImage Inited.\n");
            ChangeTo96Dpi(rgbImage);
            rgbBms = (BitmapSource)this.rgbImage.Source;
            BmsEngine.Init(rgbBms);
            rgbValues = BmsEngine.GetRgbData();
            byte[] newJpegBytes = new byte[BmsEngine.dataLength];
            for (int i = 0; i < BmsEngine.dataLength; i += 4)
            {
                newJpegBytes[i + (int)RGB.Red] = newJpegBytes[i + (int)RGB.Green] = newJpegBytes[i + (int)RGB.Blue] = (byte)(hslValues[i + (int)HSL.Lightness] * 255);
            }
            lBms = BmsEngine.CloneBms(newJpegBytes);
        } // OnLoad()
    }
}
