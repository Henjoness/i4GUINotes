﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageSharpening
{
    static class StandardBlur
    {

        private static double[] kernel;
        private static float[] src;
        private static int numColumns, numRows;
        private static ProgressBarUpdateDelegate reporterCallback;
        private static float[] lBlurred;       //row blur results
        private static float[] cBlurred;       //column blur results


        private static float evalHBlur(int srcIndex)
        {
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                blurValue += src[srcIndex++] * kernel[i];
            }
            return (float)blurValue;
        }


        //calc blurred pixel on left edge at srcIndex
        //srcIndex goes one over on last row because kernel is 600 long
        //exceeding port length.
        //No Check that 3*sigma will not exceed port width!
        //If port width or height not > 6*sigma, an not blur
        private static float evalLeftHBlur(int rowNumber, int srcIndex)
        {
            int startRowIndex = rowNumber * numColumns;
            double firstColumnValue = src[startRowIndex];
            srcIndex -= kernel.Length / 2;
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                if (srcIndex >= startRowIndex)
                    blurValue += src[srcIndex] * kernel[i];
                else
                    blurValue += firstColumnValue * kernel[i];
                srcIndex++;
            }
            return (float)blurValue;
        } //evalLeftHBlur()


        //calc blurred pixel on right edge at srcIndex
        private static float evalRightHBlur(int rowNumber, int srcIndex)
        {
            int endRowIndex = (rowNumber + 1) * numColumns - 1;
            double lastColumnValue = src[endRowIndex];
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                if (srcIndex <= endRowIndex)
                    blurValue += src[srcIndex] * kernel[i];
                else
                    blurValue += lastColumnValue * kernel[i];
                srcIndex++;
            }
            return (float)blurValue;
        } //evalLeftHBlur()


        private static void RowBlur(int rowNum)
        {
            int srcIndex = rowNum * numColumns;         // into hslValues
            int dstIndex = rowNum * numColumns;     // into lBlurred, it only has l channel so 1/4th the size
            //kernel.Length is odd
            //can not blur the first kernel.Length/2 pixels because at a side boundary           
            for (int i = 0; i < kernel.Length / 2; i++)
            {
                lBlurred[dstIndex] = evalLeftHBlur(rowNum, srcIndex);
                srcIndex++;
                dstIndex++;
            }

            srcIndex = rowNum * numColumns;             //starting at beginning of row
            dstIndex = rowNum * numColumns + kernel.Length / 2;
            for (int i = 0; i < numColumns - (kernel.Length - 1); i++)
            {
                lBlurred[dstIndex] = evalHBlur(srcIndex);
                dstIndex++;
                srcIndex++;
            }

            for (int i = 0; i < kernel.Length / 2; i++)
            {
                lBlurred[dstIndex] = evalRightHBlur(rowNum, srcIndex);
                srcIndex++;
                dstIndex++;
            }
        } // RowBlur();


        //make lBlur
        private static void HorizontalBlur()
        {
            if (reporterCallback!=null) reporterCallback(0);

            int reportBack = numRows / 20;
            for (int i = 0; i < numRows; i++)
            {
                RowBlur(i);
                if (i % reportBack == 0)
                {
                    if (reporterCallback != null) reporterCallback((int)(i / reportBack * 2.5));
                }
            }
        } // HorizontalBlur()


        private static float evalVBlur(int srcIndex, int numColumns)
        {
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                blurValue += lBlurred[srcIndex] * kernel[i];
                srcIndex += numColumns;
            }
            return (float)blurValue;
        } // evalVBlur()


        private static float evalTopVBlur(int srcIndex, int numColumns, float fillValue)
        {
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                if (srcIndex >= 0)
                    blurValue += lBlurred[srcIndex] * kernel[i];
                else
                    blurValue += fillValue * kernel[i];
                srcIndex += numColumns;
            }
            return (float)blurValue;
        }  //evalTopVBlur()


        private static float evalBottomVBlur(int srcIndex, int numColumns, float fillValue)
        {
            double blurValue = 0;
            for (int i = 0; i < kernel.Length; i++)
            {
                if (srcIndex < lBlurred.Length)
                    blurValue += lBlurred[srcIndex] * kernel[i];
                else
                    blurValue += fillValue * kernel[i];
                srcIndex += numColumns;
            }
            return (float)blurValue;
        } // evalBottomVBlur()


        private static void ColumnBlur(int columnNum)
        {
            int srcIndex = columnNum - (kernel.Length / 2) * numColumns; // this is negative
            int dstIndex = columnNum;
            float fillValue = lBlurred[columnNum];
            for (int i = 0; i <= kernel.Length / 2; i++)
            {
                cBlurred[dstIndex] = evalTopVBlur(srcIndex, numColumns, fillValue);
                dstIndex += numColumns;
                srcIndex += numColumns;
            }

            srcIndex = columnNum;
            dstIndex = columnNum + (kernel.Length / 2) * numColumns;    //down kernel.Length/2 rows
            for (int i = 0; i < numRows - (kernel.Length - 1); i++)
            {
                cBlurred[dstIndex] = evalVBlur(srcIndex, numColumns);
                dstIndex += numColumns;
                srcIndex += numColumns;
            }

            dstIndex = (numRows - kernel.Length / 2) * numColumns + columnNum;
            srcIndex = dstIndex - (kernel.Length / 2 * numColumns);
            fillValue = lBlurred[(numRows - 1) * numColumns];
            for (int i = 0; i < kernel.Length / 2; i++)
            {
                cBlurred[dstIndex] = evalBottomVBlur(srcIndex, numColumns, fillValue);
                dstIndex += numColumns;
                srcIndex += numColumns;
            }
        } // ColumnBlur()


        private static void VerticalBlur()
        {
            int reportBack = numColumns / 20;

            for (int i = 0; i < numColumns; i++)
            {
                ColumnBlur(i);
                if (i % reportBack == 0)
                {
                    if (reporterCallback != null) reporterCallback(50 + (int)(i / reportBack * 2.5));
                }
            }
        } // VerticalBlur()


        //This is the only public procedure
        //do a StandardBlur on srcArray input either in foreground or background
        public static float[] Blur(float[] srcArray, int numColumns,
                                ProgressBarUpdateDelegate backgroundReporter,
                                double[] kernel)
        {
            StandardBlur.src = srcArray;
            StandardBlur.numColumns = numColumns;
            numRows = srcArray.Length / numColumns;
            //Before beginning check to see src is big enough to calc a Standard Blur)
            reporterCallback = backgroundReporter;
            StandardBlur.kernel = kernel;
            lBlurred = new float[srcArray.Length];
            cBlurred = new float[srcArray.Length];
            HorizontalBlur();
            VerticalBlur();
            return cBlurred;
       } //Blur()
    }
}
