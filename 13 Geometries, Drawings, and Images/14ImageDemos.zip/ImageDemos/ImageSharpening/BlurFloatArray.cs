﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace ImageSharpening
{
    class BlurFloatArray
    {
        private GaussKernel gk = new GaussKernel();
        private double sigma;       //standard deviation for blur, must be set before method set
        double[] kernel;
        private int method;        // default is Standard,  change only after sigma is set
        private int srcNumColumns, srcNumRows;  //for full srcValues
        private float[] srcValues;              //full unblurred source values
        private float[] rectValues;             //rectangular subset unblurred source values from srcValues
        private Int32Rect subset;               //identifies rectangular subset of unblurred values from srcValues
        private float[] blurredValues;          //set when blur completes
        private ProgressBarUpdateDelegate backgroundReporter;

        // sets up the full source for a blur
        // blurs can be done on full src or a rectangular subset of srcValues
        public BlurFloatArray(float[] values, int numColumns)
        {
            srcValues = values;
            srcNumColumns = numColumns;
            srcNumRows = values.Length / numColumns;
            sigma = gk.Sigma;
            kernel = gk.Kernel;
        } //ctor()


        //changes standard dev for a standard blur.
        //call blurArray() after this!
        public double Sigma
        {
            set
            {
                //if curent method is StandardGauss and sigma changed, need a new gauss kernel
                if (method == (int)BlurMethod.StandardGauss)
                {
                    if (gk.Sigma != value)
                    {
                        gk.Sigma = value;
                        kernel = gk.Kernel; // isn't this the same as making it public. I think its writeable
                    }
                }
                else IterativeBlur.Sigma = value;
                sigma = value;      //do I need this?
            }
        } // set Sigma property


        //changes the blur method, either Standard or Iterative
        public int Method
        {
            set
            {
                method = value;         //set method
                if (method == (int)BlurMethod.StandardGauss && gk.Sigma != value)
                {
                    gk.Sigma = value;
                    kernel = gk.Kernel; // isn't this the same as making it public. I think its writeable
                }
            }
        } //set method property


        // blur all srcValues, not just rectangular subset
        public float[] Blur( ProgressBarUpdateDelegate backgroundReporter )
        {
            if (backgroundReporter == null)
            {
                this.backgroundReporter = null;
            }
            else
            {
                this.backgroundReporter = backgroundReporter;
            }
            return BlurArray(srcValues, srcNumColumns);                              
        } // blur()


        //xferr a rectangular subset of srcValues into an array, do a blur on array and return results
        //this is for the blur preview window only
        public float[] BlurRect(Int32Rect rect)
        {
            if (method == (int)BlurMethod.StandardGauss)
            { //is the window big enough for a standard blur?
                if (rect.Width < kernel.Length || rect.Height < kernel.Length)
                {
                    Msg.ShowMsg("WARNING!!!\n  Window too small\n  for preview\n");
                    return new float[rect.Width*rect.Height];
                }
            }
                float[] blurArray = new float[rect.Width * rect.Height];  //rectangular subset of values to blur
                int blurIndex = 0;
                for (int i = 0; i < rect.Height; i++)   // xfer all rows
                {
                    int srcIndex = (rect.Y + i) * srcNumColumns + rect.X;   //init to start of a row in srcValues
                    for (int j = 0; j < rect.Width; j++)                    //xfer a row i
                        blurArray[blurIndex++] = srcValues[srcIndex++];
                }
                rectValues = blurArray;                                     //save retangle and vaalues for future use
                subset = rect;
                this.backgroundReporter = null;
                BlurArray(rectValues, subset.Width);
            return blurredValues;              
        } // BlurRect()



        //given parmeters, invokes proper method to perform blur on an array
        private float[] BlurArray( float[] srcArray, int numColumns)
        {
            if (method == (int)BlurMethod.StandardGauss)
                blurredValues = StandardBlur.Blur(srcArray, numColumns, backgroundReporter, kernel);
            else
                blurredValues = IterativeBlur.Blur(srcArray, numColumns, backgroundReporter);
            return blurredValues;
        } // BlurArray()
 }
}
