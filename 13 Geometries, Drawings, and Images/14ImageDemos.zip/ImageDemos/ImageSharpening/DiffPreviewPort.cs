﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.IO;
using System.Windows.Markup;
using System.Windows.Threading;


namespace ImageSharpening
{
    class DiffPreviewPort
    {
        private static BlurPreviewCallback closeCallback;   //called on OK or Cancel
        private BitmapSource imageBms;                      //original image;
        private int imageBmsStride;
        public WriteableBitmap previewBitmap;               //writeable clone of image
        private byte[] viewBytes;           //byte array for rectangular PreviewPort from imageBytes
        private int viewStride;             //stride of viewBytes (retangle width)
        private Int32Rect viewRectangle;    //rectangle into imageBms defining viewBytes   X, Y, Width, Height

        private Window portWindow;
        private ScrollViewer scroller;
        private Slider brightnessSlider,zoomSlider,threshHoldSlider;
        private Button ok, cancel;
        private RadioButton lightenAndDarken, darkenOnly, lightenOnly;
        public TextBox brightnessText, zoomText, threshHoldText;
        public Boolean doDiff = false;
        public Boolean exited = false;
        public double blurValue = 1.0;
        private Image blurPreviewImage;     //dupe of original image, may not be what XAML loaded/
        private float[] lValues;            //passed
        private float[] blurredLValues;     //passed
        private byte[] diffedJpegBytes;     //calculated

        private EdgeEnhancement edgeEnhancement = EdgeEnhancement.LightAndDark;

        private Point mouseDragStartPoint;
        private Point scrollStartOffset;

        private DiffDisplay diffDisplay;


        // 1 image blurPreviewImage
        // 2 image sources, imageBMS and previewBitmap
        // blurPreviewImage has a writeable Bitmap (previewBitMap).  Starts off as Clone of original image
        // Scrolling view port shows orignal image.  Else blurPreviewImage shown.
        // blurPreviewIMage is not scrolled, but since in ScrollViewer, need full image.
        // Whenever viewport is changed, selected rectangle from orignalImage is copied to viewBytes then to blurPreviewImage.
        // When Blur slider changed, viewBytes is modified with new Blur n - Probably have to refetch it from Original Image.!!!!!
        // 
        // This class displays images, but blur classes work with array of floats
        // Converstions to/from image to array of floats must be done here.
        public DiffPreviewPort(Image originalImage, BitmapSource lBms, float[] lValues, float[] blurredLValues, BlurPreviewCallback bpc)
        {
            imageBms = (BitmapSource) originalImage.Source;
            this.lValues = lValues;
            this.blurredLValues = blurredLValues;
            closeCallback = bpc;

            imageBmsStride = imageBms.PixelWidth * ((imageBms.Format.BitsPerPixel + 7) / 8);
            previewBitmap = new WriteableBitmap(imageBms);
            portWindow = new Window();
            portWindow.Height = 600;
            portWindow.Width = 400;
            portWindow.Title = "Diff Port";
            string dir = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
            FileStream s = new FileStream(dir+"\\DiffPreview.xaml", FileMode.Open);
            DependencyObject rootElement = (DependencyObject)XamlReader.Load(s);
            portWindow.Content = rootElement;
            scroller = (ScrollViewer)LogicalTreeHelper.FindLogicalNode(rootElement, "scroller");
            brightnessSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "BrightnessSlider");
            brightnessText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "BrightnessText");
            threshHoldSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "ThreshHoldSlider");
            threshHoldText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "ThreshHoldText");
            zoomText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomText");
            zoomSlider = (Slider)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomSlider");
            brightnessText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "BrightnessText");
            zoomText = (TextBox)LogicalTreeHelper.FindLogicalNode(rootElement, "ZoomText");
            blurPreviewImage = (Image)LogicalTreeHelper.FindLogicalNode(rootElement, "blurPreviewImage");
            ok = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "OK");
            cancel = (Button)LogicalTreeHelper.FindLogicalNode(rootElement, "Cancel");
            lightenAndDarken = (RadioButton)LogicalTreeHelper.FindLogicalNode(rootElement, "LightenAndDarken");
            darkenOnly = (RadioButton)LogicalTreeHelper.FindLogicalNode(rootElement, "Darken");   //not Working
            lightenOnly = (RadioButton)LogicalTreeHelper.FindLogicalNode(rootElement, "Lighten");   //not Working

            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap
            //XAML bindings do not have converters, overwrite them
            BindIValueConverter(zoomSlider, zoomText);
            BindIValueConverter(brightnessSlider, brightnessText);
            BindIValueConverter(threshHoldSlider, threshHoldText);

            imageBms = lBms;

            portWindow.Show();


            TransformGroup tranGroup = new TransformGroup();
            ScaleTransform scaleTran = new ScaleTransform(1.0, 1.0, scroller.ExtentWidth / 2, scroller.ExtentHeight / 2);
            tranGroup.Children.Add(scaleTran);
            TranslateTransform translateTran = new TranslateTransform(0, 0);
            tranGroup.Children.Add(translateTran);
            blurPreviewImage.RenderTransform = tranGroup;

            scroller.ScrollToHorizontalOffset((scroller.ExtentWidth / 2) - (scroller.ViewportWidth / 2));
            scroller.ScrollToVerticalOffset((scroller.ExtentHeight / 2) - (scroller.ViewportHeight / 2));
            this.ViewRectangle = SetRectView();

            blurPreviewImage.MouseLeftButtonDown += image_MouseLeftButtonDown;
            blurPreviewImage.MouseRightButtonDown += image_MouseRightButtonDown;
            blurPreviewImage.MouseLeftButtonUp += image_MouseLeftButtonUp;
            blurPreviewImage.MouseMove += image_MouseMove;

            zoomSlider.ValueChanged += zoomSlider_ValueChanged;
            brightnessSlider.ValueChanged += brightnessSlider_ValueChanged;
            threshHoldSlider.ValueChanged += CheckRefresh;
            portWindow.SizeChanged += window_SizeChanged;
            portWindow.Closed += portClosed_Click;

            ok.Click += ok_Click;
            cancel.Click += cancel_Click;

            lightenAndDarken.Checked += CheckRefresh;
            lightenOnly.Checked += CheckRefresh;
            darkenOnly.Checked += CheckRefresh;

            scroller.ScrollChanged += scrollerChanged;
        }

        public byte[] DiffJpeg
        {
            get
            {
                return diffedJpegBytes;
            }
        }

        public double ThreshHold
        {
            get
            {
                return threshHoldSlider.Value;
            }
        }


        public EdgeEnhancement EdgeEnhancement
        {
            get
            {
                return edgeEnhancement;
            }
        }


        public void UnHide()
        {
            doDiff = false;
            this.viewRectangle = SetRectView();
            portWindow.Visibility = System.Windows.Visibility.Visible;
            portWindow.Topmost = true;
        }  //UnHide()


        public void Close()
        {
            portWindow.Close();
        }//Close()


        private void BindIValueConverter(Slider srcSlider, TextBox dstTextBox)
        {
            Binding binding = new Binding();
            binding.Source = srcSlider;
            binding.Path = new PropertyPath("Value");
            binding.Mode = BindingMode.TwoWay;
            SliderConverter sliderConverter = new SliderConverter();
            binding.Converter = new SliderConverter();
            dstTextBox.SetBinding(TextBox.TextProperty, binding);
        } //BindIValueConverter()

 
        private float[] DiffRect(Int32Rect rect)
        {
            float[] diff = new float[rect.Width * rect.Height];
            int numColumns = rect.Width;
            int numRows = rect.Height;
            int lStride = imageBmsStride / 4;
            int srcIndex = rect.Y * lStride + rect.X;
            int diffIndex = 0;

            if (lightenAndDarken.IsChecked == true)
            {
                for (int i=0; i<numRows; i++)
                {
                    for (int j = 0; j < numColumns; j++)
                    {
                        diff[diffIndex++] = Math.Abs(lValues[srcIndex] - blurredLValues[srcIndex]);
                        srcIndex++;
                    }
                    srcIndex += (lStride - numColumns);
                }
            }

            else if (darkenOnly.IsChecked == true)
            {
                for (int i = 0; i < numRows; i++)
                {
                    for (int j = 0; j < numColumns; j++)
                    {
                        if (lValues[srcIndex] > blurredLValues[srcIndex])
                            diff[diffIndex++] = Math.Abs(lValues[srcIndex] - blurredLValues[srcIndex]);
                        else diff[diffIndex++] = 0;
                        srcIndex++;
                    }
                    srcIndex += (lStride - numColumns);
                }
            }

            else if (lightenOnly.IsChecked == true)
            {
                for (int i = 0; i < numRows; i++)
                {
                    for (int j = 0; j < numColumns; j++)
                    {
                        if (lValues[srcIndex] < blurredLValues[srcIndex])
                            diff[diffIndex++] = Math.Abs(lValues[srcIndex] - blurredLValues[srcIndex]);
                        else diff[diffIndex++] = 0;
                        srcIndex++;
                    }
                    srcIndex += (lStride - numColumns);
                }
            }
            return diff;
        }  //DiffRect();


        //Copy rectangle selected pixels from ImageBms into viewBytes array
        public Int32Rect ViewRectangle
        {
            set
            {
                        viewBytes = new byte[value.Height * value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8)];
                        viewStride = value.Width * ((imageBms.Format.BitsPerPixel + 7) / 8);
                        float[] viewLBytes = DiffRect(value);
                        if (diffDisplay == null) diffDisplay = new DiffDisplay(viewLBytes);
                        diffDisplay.LSrc = viewLBytes;
                        viewBytes = diffDisplay.Display;
                        viewRectangle = value;
            }
        } // ViewRectangle Property
 


        //Updates previewBMS with rectangle selected pixels in viewBytes
        public WriteableBitmap UpdateWithView()
        {
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)
            return previewBitmap;
        }


        private void window_SizeChanged(Object sender, SizeChangedEventArgs e)
        {
            this.viewRectangle = new Int32Rect((int)scroller.HorizontalOffset, (int)scroller.VerticalAlignment,
                                               (int)scroller.ViewportWidth,    (int)scroller.ViewportHeight);
            Msg.ShowScrollerSize("Diff Port resized\n", scroller);
        }


        //PROBABLY WILL NOT NEED THIS ANYMORE!!!
        private Int32Rect SetRectView()
        {
            Int32Rect rect = new Int32Rect();
            
            if (scroller.HorizontalOffset>=0 && scroller.HorizontalOffset<blurPreviewImage.Source.Width)
                rect.X = (int)scroller.HorizontalOffset;
            else rect.X = 0;
            if (scroller.VerticalOffset>= 0 && scroller.VerticalOffset<=blurPreviewImage.Source.Height)
                rect.Y = (int)scroller.VerticalOffset;
            else rect.Y = 0;

            rect.Width = Math.Min((int)blurPreviewImage.Source.Width - rect.X, (int)(scroller.ViewportWidth * 100 / zoomSlider.Value));
            rect.Height = Math.Min((int)blurPreviewImage.Source.Height - rect.Y, (int)(scroller.ViewportHeight * 100 / zoomSlider.Value));
            return rect;
        }


        private void scrollerChanged(object sender, ScrollChangedEventArgs e)
        {
            this.viewRectangle = SetRectView();
        } //ScrollerChanged()


        private void image_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (blurPreviewImage.Source == previewBitmap)
                blurPreviewImage.Source = imageBms;
            else
                 blurPreviewImage.Source = previewBitmap;
       }


        private void image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];
            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2 );// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = 1.0;
            zoomSlider.Value = 100;

            mouseDragStartPoint = e.GetPosition(scroller);
            scrollStartOffset.X = scroller.HorizontalOffset;
            scrollStartOffset.Y = scroller.VerticalOffset;
            blurPreviewImage.Source = imageBms;             //display orignal image

            bool x = blurPreviewImage.CaptureMouse();
        } // image_MouseLeftButtonDown()


        private void image_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.ViewRectangle = viewRectangle;
            previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            blurPreviewImage.Source = previewBitmap;        //display writeable bitmap (port view)

            if (blurPreviewImage.IsMouseCaptured)
            {
                blurPreviewImage.ReleaseMouseCapture();
            }
        } // image_MouseLeftButtonUp()


        private void image_MouseMove(object sender, MouseEventArgs e)
        {
            bool x = blurPreviewImage.IsMouseCaptured;
            if (blurPreviewImage.IsMouseCaptured)
            {
                // Get the new mouse position. 
               Point mouseDragCurrentPoint = e.GetPosition(scroller);    //should it be off portwindow or image?

                // Determine the new amount to scroll. 
                Point delta = new Point(
                    (mouseDragCurrentPoint.X > this.mouseDragStartPoint.X) ?
                    -(mouseDragCurrentPoint.X - this.mouseDragStartPoint.X) :
                    (this.mouseDragStartPoint.X - mouseDragCurrentPoint.X),
                    (mouseDragCurrentPoint.Y > this.mouseDragStartPoint.Y) ?
                    -(mouseDragCurrentPoint.Y - this.mouseDragStartPoint.Y) :
                    (this.mouseDragStartPoint.Y - mouseDragCurrentPoint.Y));

                // Scroll to the new position.
                double scrollX, scrollY;
                scrollX = this.scrollStartOffset.X + delta.X; // *100 / zoomSlider.Value;
                scrollY = this.scrollStartOffset.Y + delta.Y; // *100 / zoomSlider.Value;
                scroller.ScrollToHorizontalOffset(scrollX);
                scroller.ScrollToVerticalOffset(scrollY);
            }
        } // image_MouseMove()


        private void zoomSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            TransformGroup tGroup = (TransformGroup)blurPreviewImage.RenderTransform;
            ScaleTransform sTransform = (ScaleTransform)tGroup.Children[0];

            sTransform.CenterY = scroller.VerticalOffset + (scroller.ViewportHeight / 2);// *100 / zoomSlider.Value;
            sTransform.CenterX = scroller.HorizontalOffset + (scroller.ViewportWidth / 2);// *100 / zoomSlider.Value;
            sTransform.ScaleX = sTransform.ScaleY = e.NewValue / 100;
            if (e.NewValue < 100 && e.NewValue<e.OldValue)
            {
                Int32Rect rect = new Int32Rect();
                rect.X = (int)(sTransform.CenterX - (scroller.ViewportWidth / 2) *100 / zoomSlider.Value);
                if (rect.X < 0) rect.X = 0;
                if (rect.X > scroller.ExtentWidth) rect.X = (int)scroller.ExtentWidth;
                rect.Y = (int)(sTransform.CenterY - (scroller.ViewportHeight / 2) *100 / zoomSlider.Value);
                if (rect.Y < 0) rect.Y = 0;
                if (rect.Y > scroller.ExtentHeight) rect.Y = (int)scroller.ExtentHeight;
                rect.Width = Math.Min((int)((scroller.ViewportWidth) * 100 / zoomSlider.Value), (int)(scroller.ExtentWidth-rect.X));
                rect.Height = Math.Min((int)((scroller.ViewportHeight) * 100 / zoomSlider.Value), (int)(scroller.ExtentHeight-rect.Y));
                this.ViewRectangle = rect;
                previewBitmap.WritePixels(viewRectangle, viewBytes, viewStride, 0);
            }
        } // zoomSlider_ValueChanged()


        private void brightnessSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            diffDisplay.Brightness = (int)(brightnessSlider.Value);
            this.ViewRectangle = viewRectangle;
            UpdateWithView();
        } // brightnesSlider_ValueChanged()


        private EdgeEnhancement GetEdgeEnhancement()
        {
            if (lightenAndDarken.IsChecked == true) return EdgeEnhancement.LightAndDark;
            else if (darkenOnly.IsChecked == true) return EdgeEnhancement.DarkOnly;
            else return EdgeEnhancement.LightOnly;
        } // GetEdgeEnhancement()


        private void CheckRefresh(object sender, RoutedEventArgs e)
        {
            edgeEnhancement = GetEdgeEnhancement();
            diffDisplay.ThreshHold = (byte) threshHoldSlider.Value;
            this.ViewRectangle = viewRectangle;
            UpdateWithView();
        } //CheckRefresh()


        //Exit this Window by clicking OK, Cancel or exit the Window
        //OK and Cancel leave the Preview port Window hidden.
        //Exit zaps everything including DiffPreviewPort object via closeCallback()
        private void portClosed_Click(object sender, EventArgs e)
        {
            exited = true;
            closeCallback();
        } // portClosed_Click()
   

        private void ok_Click(object sender, RoutedEventArgs e)
        {
            doDiff = true;
            portWindow.Hide();
            Int32Rect wholeImage = new Int32Rect(0, 0, imageBms.PixelWidth, imageBms.PixelHeight);
            this.ViewRectangle = wholeImage;
            diffedJpegBytes = viewBytes;
            closeCallback();
        } //ok_Click()


        private void cancel_Click(object sender, RoutedEventArgs e)
        {
            portWindow.Hide();
            doDiff = false;
            closeCallback();
        } //cancel_Click()


        //recalculate the Diff using passed L values from a new blur
        public void recalculateDiff(float[] newLBlur)
        {
            blurredLValues = newLBlur;
        }


    } // class BlurPreviewPort

}