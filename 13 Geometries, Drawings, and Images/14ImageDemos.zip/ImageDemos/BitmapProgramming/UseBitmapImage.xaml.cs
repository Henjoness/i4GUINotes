using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BitmapProgramming
{
    /// <summary>
    /// Interaction logic for UseBitmapImage.xaml
    /// </summary>

    public partial class UseBitmapImage : System.Windows.Window
    {

        public UseBitmapImage()
        {
            InitializeComponent();

            // Using BitmapImage

            Image imageElement = new Image();
            imageElement.Source = new BitmapImage(new Uri(
              "http://www.nasa.gov/images/content/136054main_bm_072004.jpg"));
            this.Content = imageElement;

            ModifyPixels wnd1 = new ModifyPixels();
            wnd1.Show();

            AddCaption wnd2 = new AddCaption();
            wnd2.Show();

            UseRenderTargetBitmap wnd3 = new UseRenderTargetBitmap();
            wnd3.Show();
        }

    }
}