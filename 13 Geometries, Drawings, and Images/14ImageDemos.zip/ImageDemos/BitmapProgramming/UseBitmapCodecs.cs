using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media.Imaging;
using System.IO;

namespace BitmapProgramming
{
    class UseBitmapCodecs
    {
        // Example 13-35. Creating a JPEG file

        static void WriteJpeg(string fileName, int quality, BitmapSource bmp)
        {

            JpegBitmapEncoder encoder = new JpegBitmapEncoder();
            BitmapFrame outputFrame = BitmapFrame.Create(bmp);
            encoder.Frames.Add(outputFrame);
            encoder.QualityLevel = quality;

            using (FileStream file = File.OpenWrite(fileName))
            {
                encoder.Save(file);
            }
        }

        // End of Example 13-35.


        // Example 13-36. Reading bitmap metadata

        static string GetCamera(string myJpegPath)
        {
            JpegBitmapDecoder decoder = new JpegBitmapDecoder(new Uri(myJpegPath),
                BitmapCreateOptions.None, BitmapCacheOption.None);
            BitmapMetadata bmpData = (BitmapMetadata) decoder.Frames[0].Metadata;
            return bmpData.CameraModel;
        }

        // End of Example 13-36.

    }
}
